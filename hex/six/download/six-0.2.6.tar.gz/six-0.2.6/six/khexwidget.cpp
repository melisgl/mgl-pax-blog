#include "misc.h"

#include "khexwidget.h"

#include <qpainter.h>
#include <qpixmap.h>
#include <qlayout.h>
#include <qpointarray.h>

#include <iostream>

KHexWidget::KHexWidget(QWidget *parent) : QWidget(parent)
{
  _bufferOld = true;
  _numbering = false;
  _displayMode = DISPLAY_DIAGONAL;
  setBackgroundMode(NoBackground);
  connect(&_timer, SIGNAL(timeout()), this, SLOT(flash()));

  _blackPen = QPen(QColor("black"));
  _whitePen = QPen(QColor("white"));
  _blackBrush = QBrush(QColor("black"));
  _whiteBrush = QBrush(QColor("white"));
  _greyBrush = QBrush(QColor("grey"));
  _lightGreyBrush = QBrush(QColor("lightgrey"));
}

KHexWidget::~KHexWidget()
{
}

QSizePolicy KHexWidget::sizePolicy() const
{
  return QSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
}

void KHexWidget::flashHexagons(const vector<int> &hexagons,
                               int interval, int nFlashes)
{
  stopFlash();
  _flashingHexagons = hexagons;
  _timer.start(interval);
  _timeoutCounter = nFlashes * 2;
  flash();
}

void KHexWidget::drawCenteredText(QPainter *p, int x, int y, const QString &s)
{
  QRect re = p->fontMetrics().boundingRect(s);
  int w = p->fontMetrics().width(s);
  int h = re.height();
  p->drawText(x - w / 2 , y + h / 2 , s);
}

void KHexWidget::setUpEdge(QPointArray &edge, int n,
                           int x0, int y0, int x1, int y1, int x2, int y2,
                           int dx, int dy)
{
  int qx = x1 / 3;
  int qy = y1 / 3;
  for(int i = 0; i < n; i++) {
    edge.setPoint(edge.size() / 2 - 2 * i - 1,
                  x0 + i * dx, y0 + i * dy);
    if(i == 0) {
      edge.setPoint(edge.size() / 2 + 2 * i,
                    x0 / 3 + x0 + i * dx, y0 / 3 + y0 + i * dy);
    } else {
      edge.setPoint(edge.size() / 2 + 2 * i,
                    qx + x0 + i * dx, qy + y0 + i * dy);
    }
    edge.setPoint(edge.size() / 2 - 2 * i - 2,
                  x1 + i * dx, y1 + i * dy);
    edge.setPoint(edge.size() / 2 + 2 * i + 1,
                  qx + x1 + i * dx, qy + y1 + i * dy);
  }
  edge.setPoint(0,
                x2 + (n - 1) * dx,  y2 + (n - 1) * dy);
  edge.setPoint(edge.size() - 1,
                x2 / 3 + x2 + (n - 1) * dx,  y2 / 3 + y2 + (n - 1) * dy);
}

void KHexWidget::drawBoard(QPainter *p, const HexBoard &b,
                           int hxs, int hys,
                           int colDx, int colDy, int rowDx, int rowDy,
                           bool storeHexagons)
{
  p->save();
  int bxs = b.xs();
  int bys = b.ys();
  int hms = MAX(hxs, hys);
  QRect prect(-hms * 5 / 8, -hms * 5 / 8, hms * 10 / 8, hms * 10 / 8);
  QFont font("times", hxs / 2, QFont::Bold);
  QFontMetrics fm(font);
  QPointArray pa(6);
  if(_displayMode == DISPLAY_DIAGONAL) {
    pa.setPoints(6, hxs, 0, hxs / 2, hys, -hxs / 2, hys, -hxs, 0,
                 -hxs / 2, -hys, hxs / 2, -hys);
  } else {
    pa.setPoints(6, 0, hys, -hxs, hys / 2, -hxs, -hys / 2,
                 0, -hys, hxs, -hys / 2, hxs, hys / 2);
  }
  p->setFont(font);
  p->setBrush(_greyBrush);
  for(int y = 0; y < bys; y++) {
    p->save();
    drawCenteredText(p, -colDx, -colDy, QString::number(y + 1));
    for(int x = 0; x < bxs; x++) {
      if(y == 0)
        drawCenteredText(p, -rowDx, -rowDy, QString(QChar('A' + x)));
      if(y == bys - 1)
        drawCenteredText(p, +rowDx, +rowDy, QString(QChar('A' + x)));
      p->drawPolygon(pa);
      if(b.get(b.coords2Field(x, y)) == HEX_MARK_VERT) {
        p->save();
        p->setPen(_blackPen);
        p->setBrush(_blackBrush);
        p->drawPie(prect, 0, 5760);
        p->restore();
      } else if(b.get(b.coords2Field(x, y)) == HEX_MARK_HORI) {
        p->save();
        p->setPen(_whitePen);
        p->setBrush(_whiteBrush);
        p->drawPie(prect, 0, 5760);
        p->restore();
      }
      if(storeHexagons) {
        _hexagonPolygons[y * bxs + x] = p->worldMatrix().map(pa);
        _hexagonRegions[y * bxs + x] = QRegion(_hexagonPolygons[y * bxs + x]);
      }
      p->translate(colDx, colDy);
    }
    drawCenteredText(p, 0, 0, QString::number(y + 1));
    p->restore();
    p->translate(rowDx, rowDy);
  }
  p->restore();
}

void KHexWidget::drawNumbering(QPainter *p, const HexGame &g,
                               int hxs, int hys,
                               int colDx, int colDy, int rowDx, int rowDy)
{
  p->save();
  p->setFont(QFont("helvetica", 2 * MAX(hxs, hys) / 5));
  int n = g.initialBoard().nMark() + 1;
  for(unsigned i = 0; i < g.moves().size(); i++) {
    const HexMove &m = g.moves()[i];
    if(!m.isSwap()) {
      int x, y;
      g.initialBoard().field2Coords(m.field(), &x, &y);
      if(i + 1 < g.moves().size() && g.moves()[i + 1].isSwap()) {
        if(m.mark() == HEX_MARK_VERT)
          p->setPen(_blackPen);
        else
          p->setPen(_whitePen);
        drawCenteredText(p, y * colDx + x * rowDx,
                         y * colDy + x * rowDy,
                         QString::number(n));
      } else {
        if(m.mark() == HEX_MARK_VERT)
          p->setPen(_whitePen);
        else
          p->setPen(_blackPen);
        drawCenteredText(p, x * colDx + y * rowDx,
                         x * colDy + y * rowDy,
                         QString::number(n));
      }
      n++;
    }
  }
  p->restore();
}

void KHexWidget::drawEdges(QPainter *p,
                           const QPointArray &e1, const QPointArray &e2)
{
  p->save();
  p->setPen(_blackPen);
  p->setBrush(_blackBrush);
  p->drawPolygon(e1);
  p->scale(-1., -1.);
  p->drawPolygon(e1);
  p->restore();

  p->save();
  p->setPen(_blackPen);
  p->setBrush(_whiteBrush);
  p->drawPolygon(e2);
  p->scale(-1., -1.);
  p->drawPolygon(e2);
  p->restore();
}

void KHexWidget::drawDiagonalEdges(QPainter *p, int bxs, int bys,
                                   int hxs, int hys,
                                   int colDx, int colDy, int rowDx, int rowDy,
                                   int xoff, int yoff)
{
  QPointArray topEdge(bxs * 4 + 2);
  QPointArray leftEdge(bys * 4 + 2);
  setUpEdge(topEdge, bxs,
            -hxs, 0, -hxs / 2, -hys, 0, -hys,
            colDx, colDy);
  setUpEdge(leftEdge, bys,
            -hxs, 0, -hxs / 2, hys, 0, hys,
            rowDx, rowDy);
  topEdge.translate(xoff, yoff);
  leftEdge.translate(xoff, yoff);

  drawEdges(p, topEdge, leftEdge);
}

void KHexWidget::drawFlatEdges(QPainter *p, int bxs, int bys,
                               int hxs, int hys,
                               int colDx, int colDy, int rowDx, int rowDy,
                               int xoff, int yoff)
{
  QPointArray topEdge(bxs * 4 + 2);
  QPointArray leftEdge(bys * 4 + 2);
  setUpEdge(topEdge, bxs,
            -hxs, -hys / 2, 0, -hys, hxs / 2, -hys * 3 / 4,
            colDx, colDy);
  setUpEdge(leftEdge, bys,
            -hxs, -hys / 2, -hxs, hys / 2, -hxs / 2, hys * 3 / 4,
            rowDx, rowDy);
  topEdge.translate(xoff, yoff);
  leftEdge.translate(xoff, yoff);

  drawEdges(p, topEdge, leftEdge);
}

void KHexWidget::print(QPainter *p, int width, int height, bool storeHexagons)
{
  int bxs = _game.board().xs();
  int bys = _game.board().ys();
  if(storeHexagons) {
    _hexagonRegions.resize(bys * bxs);
    _hexagonPolygons.resize(bys * bxs);
  }

  double zoom;
  {
    int boardXs, boardYs;
    if(_displayMode == DISPLAY_DIAGONAL) {
      boardXs = 2 * 100 + (bxs - 1 + bys - 1) * 150;
      boardYs = bys * 2 * 86;
    } else {
      boardXs = (2 * bxs + bys - 1) * 86;
      boardYs = 2 * 100 + (bys - 1) * 150;
    }
    double xa = ((double)boardXs + 300) / ((double)width);
    double ya = ((double)boardYs + 300) / ((double)height);
    zoom = MAX(xa, ya);
  }

  int hxs, hys;
  int colDx, colDy;
  int rowDx, rowDy;
  if(_displayMode == DISPLAY_DIAGONAL) {
    hxs = (int)(100. / zoom);
    hys = (int)(86. / zoom);
    colDx = hxs * 3 / 2;
    colDy = -hys;
    rowDx = hxs * 3 / 2;
    rowDy = hys;
    p->translate(width / 2, height / 2);
    int boardXsa = 2 * hxs + (bxs - 1 + bys - 1) * (hxs * 3 / 2);
    drawDiagonalEdges(p, bxs, bys, hxs, hys,
                      colDx, colDy, rowDx, rowDy,
                      -boardXsa / 2 + hxs, 0);
    p->translate(-boardXsa / 2 + hxs, 0);
  } else {
    assert(_displayMode == DISPLAY_FLAT);
    hxs = (int)(86. / zoom);
    hys = (int)(100. / zoom);
    colDx = 2 * hxs;
    colDy = 0;
    rowDx = hxs;
    rowDy = hys * 3 / 2;
    int boardXsa = (2 * bxs + bys - 1) * hxs;
    int boardYsa = 2 * hys + (bys - 1) * (hys * 3 / 2);
    p->translate(width / 2, height / 2);
    drawFlatEdges(p, bxs, bys, hxs, hys,
                  colDx, colDy, rowDx, rowDy,
                  -boardXsa / 2 + hxs, -boardYsa / 2 + hys);
    p->translate(-boardXsa / 2 + hxs, -boardYsa / 2 + hys);
  }

  drawBoard(p, _game.board(), hxs, hys, colDx, colDy, rowDx, rowDy,
            storeHexagons);
  if(_numbering)
    drawNumbering(p, _game, hxs, hys, colDx, colDy, rowDx, rowDy);
}

void KHexWidget::paintEvent(QPaintEvent *e)
{
  QRect rect = (*this).rect();
  if(_buffer.size() != rect.size() || _bufferOld) {
    _buffer.resize(rect.size());
    _buffer.fill(backgroundColor());
    QPainter p(&_buffer);
    print(&p, _buffer.width(), _buffer.height(), true);
    p.end();
    _bufferOld = false;
  }
  bitBlt(this, 0, 0, &_buffer);
}

void KHexWidget::mouseReleaseEvent(QMouseEvent *e)
{
  int xs = _game.board().xs();
  for(unsigned i = 0; i < _hexagonRegions.size(); i++) {
    if(_hexagonRegions[i].contains(e->pos())) {
      if(e->button() == LeftButton) {
        emit signalClickLeft(_game.board().coords2Field(i % xs, i / xs));
      }
      break;
    }
  }
}

void KHexWidget::setGame(const HexGame &g)
{
  _game = g;
  _bufferOld = true;
  repaint();
  emit signalChangeGame(_game);
}

void KHexWidget::setDisplayMode(DisplayMode dm)
{
  if(_displayMode != dm) {
    _displayMode = dm;
    _bufferOld = true;
    repaint();
  }
}

void KHexWidget::setNumbering(bool on)
{
  if(_numbering != on) {
    _numbering = on;
    _bufferOld = true;
    repaint();
  }
}

void KHexWidget::flash()
{
  _timeoutCounter--;
  if(!(_timeoutCounter % 2)) {
    QPainter p(this);
    p.setPen(_blackPen);
    p.setBrush(_lightGreyBrush);
    for(unsigned i = 0; i < _flashingHexagons.size(); i++)
      p.drawPolygon(_hexagonPolygons[_flashingHexagons[i]]);
  } else {
    bitBlt(this, 0, 0, &_buffer);
    if(_timeoutCounter <= 0)
      _timer.stop();
  }
}

bool KHexWidget::isFlashing() const
{
  return _timer.isActive();
}

void KHexWidget::stopFlash()
{
  if(_timer.isActive()) {
    _timer.stop();
    bitBlt(this, 0, 0, &_buffer);
  }
}

#include "khexwidget.moc"
