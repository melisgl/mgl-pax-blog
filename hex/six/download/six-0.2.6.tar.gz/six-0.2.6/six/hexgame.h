// Yo Emacs, this -*- C++ -*-
#ifndef HEXGAME_H
#define HEXGAME_H

#include "hexmove.h"
#include "hexboard.h"

#include <iostream>
#include <vector>

/**
 * A game of hex.
 * While HexBoard is only a position, HexGame is more: a game started from
 * an arbitrary position with or without the swap option.
 *
 * In short this class contains the rules of Hex.
 */
class HexGame
{
public:
  /**
   * Constructs a game that starts from the position on board <code>b</code>,
   * with the player of mark <code>first</code> to play first,
   * and with the swap option allowed according to <code>swappable</code>.
   */
  HexGame(const HexBoard &b = HexBoard(), HexMark first = HEX_MARK_VERT,
          bool swappable = true);

  /**
   * @return true iff this game was created as swappable and no swap was
   * played, yet
   */
  bool swappable() const;

  /**
   * @return the mark of the player to play first
   */
  HexMark first() const;

  /**
   * @return the mark of the player to play next
   */
  HexMark next() const;

  /**
   * @return the board position at the start of the game
   */
  const HexBoard &initialBoard() const;

  /**
   * @return the current board position
   */
  const HexBoard &board() const;

  /**
   * Tests if <code>move</code> is valid in the current state of this game.
   */
  bool isValidMove(const HexMove &move) const;

  /**
   * Plays the valid <code>move</code>.
   */
  void play(const HexMove &move);

  /**
   * FIXME: Should really be in HexMatch, shouldn't it?
   */
  HexMove unplay();

  /**
   * @return the moves played so far
   */
  const vector<HexMove> &moves() const;

  /**
   * Prints a move with proper coordinates instead of field values.
   */
  void printMove(ostream &os, const HexMove &m) const;
  
  /**
   * Prints this game.
   */
  friend ostream &operator <<(ostream &os, const HexGame &b);
private:
  HexBoard _initialBoard, _currentBoard;
  HexMark _first;
  HexMark _next;
  bool _swappable;
  vector<HexMove> _moves;
};

#endif
