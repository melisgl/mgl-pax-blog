// Yo Emacs, this -*- C++ -*-
#ifndef CONNECTOR_H
#define CONNECTOR_H

#include "hexboard.h"
#include "hexmove.h"
#include "subgame.h"
#include "slicedtask.h"

#include <deque>
#include <vector>
#include <list>
#include <slist>
#include <map>
#include <hash_map>
#include <set>

/**
 * Connector calculates and updates move by move
 * virtual [semi] connections between groups on the board for
 * either of the two players.
 *
 * The algorithm is based on the idea published by Vadim V. Anshelevich,
 * see @ref http://earthlink.net/~vanshel .
 *
 * Connections and semi-connections are stored in separate data structures
 * for every different (unordered) pair of end groups.
 * Subgames in these storages are ordered by size of their carriers
 * (smallest first). There are some parameters that control the behaviour
 * of these storages:
 * <ul>
 * <li><strong><code>hardMax</code></strong>
 * is an absolute limit for the size of the storage;
 * if the size would exceed hardMax by the addition of a subgame,
 * it is simply discarded.
 * <li><strong><code>softMax</code></strong>
 * is a soft limit for the size of the storage;
 * storage size can exceed softMax but only the first softMax subgames
 * are enqueued for processing and the rest remains waiting until
 * it gets below the softMax limit (if ever).
 * </ul>
 *
 * Setting hard limits too low may create blind spots in the calculation,
 * especially when move() is invoked repeatedly which is often the case
 * in a game. Soft limits on the other hand do not create blind spots that
 * get progressively worse with each move(), in fact temporary blind spots may
 * be explored as the situation changes.
 *
 * There is also a parameter to limit the number of semi-connections on
 * the input side of the OR rule: <strong><code>maxInOrRule</code></strong>.
 *
 * As a questionable heuristic it is possible to discard all connections
 * that result from the AND rule (concatenation) where the common group
 * by which the concatenation is done is one of the edges.
 * The <strong><code>useEdge</code></strong> parameter controls this behaviour.
 * It must be said, though, that setting this parameter true, slows
 * the computation down enormously (by a factor 10-20) since it produces
 * so much more subgames. But the gain is also high: the positional
 * (as opposed to tactical) instinct seems to come with it.
 * It is particularly crucial in the opening phase.
 *
 * The processing order of connections depends on memory addresses of
 * groups (see @ref Connector::ConnKey and @ref Connector::Conn2Key).
 * If soft or hard limits are used, it may cause one connection to be
 * processed before the limit is reached in one case while the same connection
 * might not be processed at all in another. In practice, though, it amounts
 * to little difference since none of the possible processing sequences
 * is better.
 */
class Connector
{
  friend class ConnectorTest;
public:
  /**
   * ConnKey is designed to be used as a key in maps.
   * It contains only a single @ref Group pointer.
   */
  class ConnKey
  {
    friend class ConnKeyHash;
  public:
    ConnKey(Group *g);
    // for use in map
    bool operator <(const ConnKey &) const;
    // for use in hash_map
    bool operator ==(const ConnKey &) const;
    Group *group() const;
  private:
    Group *_group;
  };

  // class ConnKeyHash
  // {
  // public:
  //   size_t operator()(const ConnKey &ck) const
  //   {
  //     return (size_t)ck._group;
  //   }
  // };

  /**
   * Conn2Key is designed to be used as a key in maps.
   * It contains two @ref Group pointers.
   */
  class Conn2Key
  {
    friend class Conn2KeyHash;
  public:
    Conn2Key(Group *g0, Group *g1);
    // for use in map
    bool operator <(const Conn2Key &) const;
    // for use in hash_map
    bool operator ==(const Conn2Key &) const;
    Group *start() const;
    Group *end() const;
  protected:
    Group *_start;
    Group *_end;
  };

  // class Conn2KeyHash
  // {
  // public:
  //   size_t operator()(const Conn2Key &ck) const
  //   {
  //     return (size_t)ck._start + (size_t)ck._end;
  //   }
  // };

  // template <class T>
  // class PoiComparator
  // {
  // public:
  //   int operator ()(const Poi<T> &t0, const Poi<T> &t1) const
  //   {
  //     ASSERT(!t0.null() && !t1.null(), "");
  //     //ASSERT: same batch
  // //     if((*t0).processed()) {
  // //       return 1;
  // //     } else if((*t1).processed()) {
  // //       return 0;
  // //     }
  //     return ((*t0).carrier().size() < (*t1).carrier().size());
  //   }
  // };


  typedef deque<Poi<SubGame> > SubGameQueue;

  typedef list<const SubGame *> ConnFan;
  typedef map<ConnKey, ConnFan> ConnFanMap;

  typedef list<Poi<SubGame> > ConnBatch;
  typedef map<Conn2Key, ConnBatch> ConnBatchMap;

  typedef list<Poi<SubGame> > SemiBatch;
  typedef map<Conn2Key, SemiBatch> SemiBatchMap;

  //typedef multiset<Poi<SubGame>, PoiComparator<SubGame> > ConnBatch;
  //typedef hash_map<Conn2Key, ConnBatch, Conn2KeyHash> ConnBatchMap;
  //typedef set<const SubGame *> ConnFan;
  //typedef hash_map<ConnKey, set<const SubGame *>, ConnKeyHash> ConnFanMap;
  //typedef multiset<Poi<SubGame>, PoiComparator<SubGame> > SemiBatch;
  //typedef hash_map<Conn2Key, SemiBatch, Conn2KeyHash> SemiBatchMap;

public:
  /**
   * Constructs a connector.
   *
   * Parameters set here cannot be changed later.
   * The default values are unlimited which makes for
   * an unreasonably slow connector for all but the smallest boards.
   */ 
  Connector(int softMaxConn = -1, int hardMaxConn = -1,
            int softMaxSemi = -1, int hardMaxSemi = -1,
            int maxInOrRule = -1, bool useEdge = false);

  /**
   * Copies connector <code>c</code>.
   * It recreates every the necessary (shared and mutable) component
   * in order to isolate the connectors from unwanted changes.
   * In short: all those Poi<SubGame> elements are recreated and added
   * to this connector.
   *
   * Tasks are not copied.
   *
   * As a not-so-important limitation of the implementation
   * connectors that have been @ref stopped() cannot be copied.
   */
  Connector(const Connector &c);

  /**
   * Calculation of subgames can take an awfully long time,
   * connector can invoke a <code>task</code> periodically.
   * If threading is out of question, this feature can be
   * used to do background tasks that can be more easily sliced
   * than the calculation performed by connector :-).
   */
  void setTask(SlicedTask *task);

  /**
   * Stops computation immediately and the connector becomes @ref stopped().
   */
  void stop();

  /**
   * If stopped a connector does not do any computation.
   * Once stopped a connector cannot be restarted.
   */
  bool stopped() const;

  /**
   * Soft limit for connection storage.
   */
  int softMaxConn() const;

  /**
   * Hard limit for connection storage.
   */
  int hardMaxConn() const;

  /**
   * Soft limit for semi-connection storage.
   */
  int softMaxSemi() const;

  /**
   * Hard limit for semi-connection storage.
   */
  int hardMaxSemi() const;

  /**
   * Limit for the number of semi-connections on the input side of the
   * OR rule.
   */
  int maxInOrRule() const;

  /**
   * Parameter that controls concatenation by edges performed by the AND rule.
   */
  bool useEdge() const;

  /**
   * Initializes the connector.
   * Sets the board and mark of interest and computes the subgames.
   */
  void init(const HexBoard &b, HexMark mark);

  /**
   * Same as init() but does not call @ref calc().
   */
  void initWithoutCalc(const HexBoard &b, HexMark mark);

  /**
   * An initialized connector can be updated incrementally
   * by making a <code>move</code> on its board. This gives a major
   * performance boost.
   *
   * @param doReinitOnEdge if @ref useEdge() is false the connector can be
   * forced to reinitialize (as if with init()) itself when the move is made
   * next to an edge of the same mark; while slower to reinitialize,
   * it can worth it, since it results in less subgames speeding up subsequent
   * move() calls.
   */
  void move(const HexMove &move, bool doReinitOnEdge = false);

  /**
   * Same as move() but does not call @ref calc().
   */
  void moveWithoutCalc(const HexMove &move, bool doReinitOnEdge = false);

  /**
   * Calculates subgames.
   * Only needed after one or more initWithoutCalc and moveWithoutCalc calls.
   */
  void calc();

  /**
   * Returns the mark of the winner. It is a shortcut for
   * <code>board().winner()</code> (see @ref HexBoard::winner())
   */
  HexMark winner() const;

  /**
   * Returns the mark of interest of this connector
   (<code>grouping().mark()</code>) if it detected a winning virtual
   * connection. Otherwise it returns @ref winner().
   */
  HexMark potentialWinner() const;

  /**
   * For a position without a @ref winner() but with a @ref potentialWinner()
   * it returns the winning virtual connection with smallest carrier.
   */
  Carrier winningCarrier() const;

  /**
   * The grouping for the current @ref board() position.
   */
  const Grouping &grouping() const;

  /**
   * The current board position.
   */
  const HexBoard &board() const;

  /**
   * Connections between groups.
   */
  const ConnBatchMap &conns() const;

  /**
   * Semi-connections between groups.
   */
  const SemiBatchMap &semis() const;
private:
  /**
   * Not implemeneted. It is here to catch erroneous calls.
   */
  Connector &operator =(const Connector &c);

  void enqueue(const Poi<SubGame> &);
  bool addConn(const Poi<SubGame> &);
  bool addSemi(const Poi<SubGame> &);
  bool minimizeConns(const SubGame &g, bool checkParamMinimality,
                     bool tryToEnqueue);
  bool minimizeSemis(const SubGame &g, bool checkParamMinimality,
                     bool tryToEnqueue);
  bool tryToAddConn(const Poi<SubGame> &);
  bool tryToAddSemi(const Poi<SubGame> &);
  void addToConnFanMap(const SubGame *sg);
  void removeFromConnFanMap(const SubGame *sg);
  bool includesAnyConn(const SubGame &g);
  void processConn(const SubGame &conn);
  void processSemi(const SubGame &semi);
  void updateConns(Group *newGroup, Group *emptyGroup,
                    const vector<Group *> &unitedGroups);
  void updateSemis(Group *newGroup, Group *emptyGroup,
                    const vector<Group *> &unitedGroups);

  void applyAnd(const SubGame &s0, const SubGame &s1);
  void applyOr(Group *x, Group *y,
                const vector<const SubGame *> &semis, int semiOffset,
                vector<Carrier> &un, vector<Carrier> &in,
                int depth);
  vector<const SubGame *> semisWithSamePath(const SubGame *sg);
  ConnBatchMap::const_iterator winningConnBatch() const;

  void setPotentialWinner(const SubGame &conn);

  SlicedTask *_task;
  bool _stop;

  int _softMaxConn;
  int _hardMaxConn;
  int _softMaxSemi;
  int _hardMaxSemi;
  int _maxInOrRule;
  bool _useEdge;
  Grouping _groups;
  SubGameQueue _subgameQueue;
  ConnFanMap _connFanMap;
  ConnBatchMap _connMap;
  SemiBatchMap _semiMap;
  HexMark _winner;
  HexMark _potentialWinner;
};

#endif
