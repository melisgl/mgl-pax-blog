// Yo Emacs, this -*- C++ -*-
#ifndef HEXMARK_H
#define HEXMARK_H

#include <iostream>

enum HexMarkT { HEX_MARK_EMPTY, HEX_MARK_VERT, HEX_MARK_HORI };
typedef enum HexMarkT HexMark;

ostream &operator <<(ostream &os, const HexMark &m);
istream &operator >>(istream &is, HexMark &m);

#endif
