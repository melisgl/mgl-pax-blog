// Yo Emacs, this -*- C++ -*-
#ifndef SIXPLAYER_H
#define SIXPLAYER_H

#include "hexplayer.h"
#include "connector.h"

/**
 * A player that uses @ref Connector and @ref Conductance
 * and performs a shallow game tree search.
 *
 * SixPlayer is capable of play at four different levels:
 * beginner, intermediate, advanced and expert levels.
 */
class SixPlayer : public HexPlayer
{
public:
  enum LevelT { BEGINNER, INTERMEDIATE, ADVANCED, EXPERT };
  typedef enum LevelT Level;

  /**
   * Constructs a new player of <code>level</code>.
   * During call to @ref play() <code>task</code> will be periodically called.
   * See @ref Connector::setTask(SlicedTask *task).
   */
  SixPlayer(Level level = BEGINNER, SlicedTask *task = 0);

  void init(const HexGame *g, HexMark yourMark);
  pair<bool, HexMove> play();

  /**
   * When called during a @ref play() it returns the best move found so far.
   * If this player is not thinking at the moment of call or no move
   * was found so far it returns a swap move.
   */
  HexMove candidateMove() const;

  /**
   * If this player is thinking it is cancelled and @ref play() returns
   * at the first possible moment.
   */
  void cancelMove();
private:
  /**
   * A move with a value and connectors for calculating updated connections.
   */
  class Move
  {
  public:
    Move() {}
    Move(HexMove m, double v) : move(m), value(v) {}
    HexMove move;
    double value;
    Poi<Connector> vert;
    Poi<Connector> hori;
    bool operator <(const Move &m) const
    {
      // m1 < m2 iff m1.second > m2.second
      return value > m.value;
    }
  };

  /**
   * A proxy SlicedTask that tracks invocations.
   */
  class TaskTracker : public SlicedTask
  {
  public:
    /**
     * Every @ref doSlice() call will invoke <code>t->doSlice()</code>.
     * While the call is active <code>activeConnector</code> is set
     * to <code>c</code>.
     */
    TaskTracker(SlicedTask *t = 0, Connector *c = 0,
                Connector **activeConnector = 0);
    void doSlice();
  private:
    SlicedTask *_task;
    Connector *_connector;
    Connector **_activeConnector;
  };

  /**
   * Appends all non-swap moves of <code>mark</code> possible in this
   * board position (@ref Connector::board())
   * and estimates the @ref Move::value.
   *
   * A move's estimated value is the sum of the energy levels of the
   * group according to the conductances for HEX_MARK_VERT and HEX_MARK_HORI.
   * See @ref Conductance::energy(GroupIndex).
   */
  void generateMoves(const Connector &vert, const Connector &hori,
                     HexMark mark, vector<Move> *moves);

  /**
   * Evaluates the position for the player of <code>mark</code>.
   * Position must be not be won (see @ref HexBoard::winner())
   * but there must be a potential winner.
   *
   * @param depth influences the value
   * @param bestMove is set to the highest energy move in the carrier of
   * winning virtual connection.
   */
  double evalPotentialWinner(const Connector &vert,
                             const Connector &hori,
                             HexMark mark,
                             HexMove *bestMove, unsigned depth);

  /**
   * Evaluates the position for player with <code>mark</code>.
   * For HEX_MARK_VERT, the value is log(Rv/Rh) where
   * Rv is the resistence for HEX_MARK_VERT and
   * Rh is the resistence for HEX_MARK_HORI.
   */
  double evalPos(const Connector &vert, const Connector &hori, HexMark mark);

  /**
   * Tries to evaluate the position for leaves in the game tree.
   * 
   * @return true iff this position should not be anylized further;
   * in other words it's a leaf.
   */
  bool tryToEvalLeaf(const Connector &vert,
                     const Connector &hori,
                     HexMark mark,
                     HexMove *bestMove, double alpha,
                     const vector<unsigned> &widths,
                     unsigned depth,
                     double *value);

  /**
   * Creates connectors from <code>oldVert</code> and <code>oldHori</code>
   * for move <code>m</code> and stores them in the move.
   */
  void move(const Connector &oldVert, const Connector &oldHori, Move *m);

  /**
   * Performs alpha-(beta) game tree search, evaluates the position,
   * suggests a move.
   *
   * @param widths controls the number of candidate moves evaluated
   * at each depth;
   * <code>widths.size()</code> is the depth of the game tree search
   * @param depth is the depth of this node in the game tree;
   * starts from zero.
   */
  double eval(HexMark mark,
              const Connector &vert, const Connector &hori,
              HexMove *bestMove, double alpha,
              const vector<unsigned> &widths, unsigned depth);

  /**
   * Creates new connectors if their parameters do not match these parameters.
   */
  void updateConnectors(int smc, int hmc, int sms, int hms, int mio, bool ue);

  pair<bool, HexMove> beginnerPlay();
  pair<bool, HexMove> intermediatePlay();
  pair<bool, HexMove> advancedPlay();
  pair<bool, HexMove> expertPlay();
  pair<bool, HexMove> commonPlay(int smc, int hmc, int sms, int hms,
                                 int mio, bool ue,
                                 const vector<unsigned> &widths);

  TaskTracker _vertTracker;
  TaskTracker _horiTracker;
  Poi<Connector> _vert;
  Poi<Connector> _hori;
  HexMove _candidateMove;

  Level _level;
  const HexGame *_game;
  HexMark _myMark;
  int _nNode;
  int _nCond;
  int _nMove;

  SlicedTask *_task;
  Connector *_activeConnector;
  bool _cancelMove;
  bool _thinking;
};

#endif
