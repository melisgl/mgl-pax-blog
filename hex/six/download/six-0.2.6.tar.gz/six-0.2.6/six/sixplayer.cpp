#include "sixplayer.h"
#include "conductance.h"
#include "misc.h"

#include <cassert>
#include <algorithm>
#include <cmath>

//
//
//

SixPlayer::TaskTracker::TaskTracker(SlicedTask *t, Connector *c,
                                    Connector **activeConnector)
{
  _task = t;
  _connector = c;
  _activeConnector = activeConnector;
}

void SixPlayer::TaskTracker::doSlice()
{
  if(_activeConnector)
    *_activeConnector = _connector;
  if(_task)
    _task->doSlice();
  if(_activeConnector)
    *_activeConnector = 0;
}

//
//
//

static int swapValue(const HexBoard &b)
{
  assert(b.nMark() == 1);
  HexMove m;
  for(HexField f = 0; f < b.size(); f++) {
    if(b.get(f) != HEX_MARK_EMPTY) {
      m = HexMove(b.get(f), f);
    }
  }
  assert(m != HexMove());
  int x, y;
  b.field2Coords(m.field(), &x, &y);
  int cMin = MIN(x, y);
  int cMax = MAX(x, y);
  if(cMin > 0) {
    return 1;
  }
  if(cMax == 0) {
    return -1;
  }
  return 0;
}

static HexMove makeSafeOpeningMove(const HexBoard &b, HexMark mark)
{
  assert(b.nMark() == 0);
  vector<HexMove> moves;
  for(HexField f = HexBoard::FIRST_NORMAL_FIELD; f < b.size(); f++) {
    HexBoard b2(b);
    b2.set(f, mark);
    if(swapValue(b2) == 0) {
      moves.push_back(HexMove(mark, f));
    }
  }
  return moves.front();
}

static HexMove highestEnergy(HexMark mark, const Carrier &c,
                             const Grouping &g,
                             const Conductance &cond)
{
  DBG << "Winning Connection: " << c << endl;
  bool found = 0;
  double max = 0.;
  int maxField = -1;
  const vector<int> &fields = c.fields();
  for(unsigned i = 0; i < fields.size(); i++) {
    double e = cond.energy(g(fields[i]));
    if(!found || e > max) {
      found = 1;
      max = e;
      maxField = fields[i];
    }
  }
  return HexMove(mark, maxField);
}

SixPlayer::SixPlayer(Level level, SlicedTask *task)
{
  _level = level;
  _task = task;
  _activeConnector = 0;
  _cancelMove = false;
  _thinking = false;
}

void SixPlayer::init(const HexGame *g, HexMark yourMark)
{
  assert(!_thinking);
  _game = g;
  _myMark = yourMark;
  _vert = 0;
  _hori = 0;
  _cancelMove = false;
}

void SixPlayer::cancelMove()
{
  if(_thinking) {
    DBG << "Cancelling move ..." << endl;
    _cancelMove = true;
    if(_activeConnector)
      _activeConnector->stop();
  }
}

double SixPlayer::evalPos(const Connector &vert,
                          const Connector &hori, HexMark m)
{
  assert(m == HEX_MARK_VERT || m == HEX_MARK_HORI);
  Conductance vertCond(vert);
  _nCond++;
  Conductance horiCond(hori);
  _nCond++;
  double rb = vertCond.resistance();
  double rw = horiCond.resistance();
  double r;
  if(m == HEX_MARK_VERT) {
    r = rw / rb;
  } else {
    r = rb / rw;
  }
  return log(r);
}

double SixPlayer::evalPotentialWinner(const Connector &vert,
                                      const Connector &hori,
                                      HexMark mark,
                                      HexMove *bestMove,
                                      unsigned depth)
{
  assert(vert.winner() == HEX_MARK_EMPTY &&
         hori.winner() == HEX_MARK_EMPTY);
  assert(vert.potentialWinner() == HEX_MARK_EMPTY ||
         hori.potentialWinner() == HEX_MARK_EMPTY);
  assert(vert.potentialWinner() != HEX_MARK_EMPTY ||
         hori.potentialWinner() != HEX_MARK_EMPTY);
  assert(vert.potentialWinner() == HEX_MARK_EMPTY ||
         vert.potentialWinner() == HEX_MARK_VERT);
  assert(hori.potentialWinner() == HEX_MARK_EMPTY ||
         hori.potentialWinner() == HEX_MARK_HORI);
  if(bestMove) {
    Carrier wc;
    Poi<Conductance> cond;
    const Grouping *grouping;
    if(vert.potentialWinner() == HEX_MARK_VERT) {
      wc = vert.winningCarrier();
      grouping = &vert.grouping();
      cond = new Conductance(vert);
      _nCond++;
    } else {
      wc = hori.winningCarrier();
      grouping = &hori.grouping();
      cond = new Conductance(hori);
      _nCond++;
    }
    *bestMove = highestEnergy(mark, wc, *grouping, *cond);
  }
  int lengthOfConn;
  if(vert.potentialWinner() == HEX_MARK_VERT) {
    lengthOfConn = vert.winningCarrier().size();
  } else {
    lengthOfConn = hori.winningCarrier().size();
  }
  if(vert.potentialWinner() == mark || hori.potentialWinner() == mark) {
    return 1000. * (10 - depth) - lengthOfConn;
  } else {
    return -1000. * (10 - depth) + lengthOfConn;
  }
}

void SixPlayer::generateMoves(const Connector &vert,
                              const Connector &hori,
                              HexMark mark, vector<Move> *moves)
{
  Conductance vertCond(vert);
  _nCond++;
  Conductance horiCond(hori);
  _nCond++;
  const Grouping &bg = vert.grouping();
  const Grouping &wg = hori.grouping();
  const HexBoard &b = vert.board();
  for(HexField f = 0; f < b.size(); f++) {
    if(b.get(f) == HEX_MARK_EMPTY) {
      HexMove m(mark, f);
      double be = vertCond.energy(bg(f));
      double we = horiCond.energy(wg(f));
      (*moves).push_back(Move(m, be + we));
    }
  }
}

bool SixPlayer::tryToEvalLeaf(const Connector &vert,
                              const Connector &hori,
                              HexMark mark,
                              HexMove *bestMove, double alpha,
                              const vector<unsigned> &widths,
                              unsigned depth,
                              double *value)
{
  if(vert.winner() != HEX_MARK_EMPTY ||
     hori.winner() != HEX_MARK_EMPTY) {
    if(vert.winner() == mark || hori.winner() == mark) {
      *value = 1000. * (10 - depth);
    } else {
      *value = -1000. * (10 - depth);
    }
    return true;
  } else if(vert.potentialWinner() != HEX_MARK_EMPTY ||
            hori.potentialWinner() != HEX_MARK_EMPTY) {
    *value = evalPotentialWinner(vert, hori, mark, bestMove, depth);
    return true;
  } else if(1000. * (10 - (depth + 1)) < alpha) {
    // if the parent node has a win and
    // we are already at the depth of that win,
    // then make a cut
    *value = -alpha;
    return true;
  } else if(depth >= widths.size()) {
    *value = evalPos(vert, hori, mark);
    return true;
  } else {
    return false;
  }
}

void SixPlayer::move(const Connector &oldVert, const Connector &oldHori,
                     Move *m)
{
  assert((*m).vert.null() == (*m).hori.null());
  if((*m).vert.null()) {
    (*m).vert = new Connector(oldVert);
    (*m).hori = new Connector(oldHori);
    TaskTracker vertTracker(_task, &*(*m).vert, &_activeConnector);
    TaskTracker horiTracker(_task, &*(*m).hori, &_activeConnector);
    (*(*m).vert).setTask(&vertTracker);
    (*(*m).hori).setTask(&horiTracker);
    if(!_cancelMove) {
      (*(*m).vert).move((*m).move);
      _nMove++;
      if(!_cancelMove) {
        (*(*m).hori).move((*m).move);
        _nMove++;
      }
    }
    (*(*m).vert).setTask(0);
    (*(*m).hori).setTask(0);
  }
}

double SixPlayer::eval(HexMark mark,
                       const Connector &vert, const Connector &hori,
                       HexMove *bestMove, double alpha,
                       const vector<unsigned> &widths, unsigned depth)
{
  double r;
  _nNode++;
  
  assert(vert.winner() == hori.winner());
  if(!tryToEvalLeaf(vert, hori, mark, bestMove, alpha, widths, depth, &r)) {
    vector<Move> moves;
    generateMoves(vert, hori, mark, &moves);
    sort(moves.begin(), moves.end());
    HexMark nextMark = ((mark == HEX_MARK_VERT) ? HEX_MARK_HORI :
                        HEX_MARK_VERT);
    bool found = 0;
    double max = -HUGE_VAL;
    HexMove maxMove;
    if(depth == 0 && !moves.empty())
      _candidateMove = moves[0].move;
    for(unsigned i = 0; i < moves.size() && i < widths[depth]; i++) {

      if(bestMove) {
        for(unsigned j = 0; j < depth; j++)
          DBG << " ";
        (*_game).printMove(DBG, moves[i].move);
        DBG << endl;
      }

      move(vert, hori, &moves[i]);
      if(_cancelMove)
        return 0.;
      double v = -eval(nextMark,
                *moves[i].vert, *moves[i].hori, 0, MAX(max, -500),
                widths, depth + 1);
      // we don't need the connectors anymore
      moves[i].vert = 0;
      moves[i].hori = 0;

      if(bestMove) {
        for(unsigned j = 0; j < depth; j++)
          DBG << " ";
        DBG << "value=" << v << "(move=";
        (*_game).printMove(DBG, moves[i].move);
        DBG << ")" << endl;
      }

      if(!found || v > max) {
        found = 1;
        max = v;
        maxMove = moves[i].move;
        if(bestMove) {
          *bestMove = moves[i].move;
          DBG << "Best move=";
          (*_game).printMove(DBG, *bestMove);
          DBG << "(" << v << ")" << endl;
        }
        if(depth == 0)
          _candidateMove = moves[i].move;
        if(-max <= alpha) {
          break;
        }
      }
    }
    assert(found);
    r = max;
  }
  return r;
}

pair<bool, HexMove> SixPlayer::play()
{
  _thinking = true;
  _candidateMove = HexMove();
  pair<bool, HexMove> r;
  switch(_level) {
  case 0:
    r = beginnerPlay();
    break;
  case 1:
    r = intermediatePlay();
    break;
  case 2:
    r = advancedPlay();
    break;
  case 3:
    r = expertPlay();
    break;
  default:
    assert(0);
  }
  _thinking = false;
  if(_cancelMove) {
    // let's make sure that we don't return a move if we're asked to cancel it
    r = pair<bool, HexMove>(false, HexMove());
  }
  return r;
}

void SixPlayer::updateConnectors(int smc, int hmc,
                                 int sms, int hms,
                                 int mio, bool ue)
{
  assert(_vert.null() == _hori.null());
  assert(_vert.null() ||
         ((*_vert).softMaxConn() == (*_hori).softMaxConn() &&
          (*_vert).hardMaxConn() == (*_hori).hardMaxConn() &&
          (*_vert).softMaxSemi() == (*_hori).softMaxSemi() &&
          (*_vert).hardMaxSemi() == (*_hori).hardMaxSemi() &&
          (*_vert).maxInOrRule() == (*_hori).maxInOrRule() &&
          (*_vert).useEdge() == (*_hori).useEdge()));
  if(_vert.null() ||
     (*_vert).softMaxConn() != smc || (*_vert).hardMaxConn() != hmc ||
     (*_vert).softMaxSemi() != sms || (*_vert).hardMaxSemi() != hms ||
     (*_vert).maxInOrRule() != mio || (*_vert).useEdge() != ue) {
    _vert = new Connector(smc, hmc, sms, hms, mio, ue);
    _hori = new Connector(smc, hmc, sms, hms, mio, ue);
    _vertTracker = TaskTracker(_task, &*_vert, &_activeConnector);
    _horiTracker = TaskTracker(_task, &*_hori, &_activeConnector);
    (*_vert).setTask(&_vertTracker);
    (*_hori).setTask(&_horiTracker);
    DBG << "Initilizing connectors ..." << endl;
    (*_vert).initWithoutCalc(_game->board(), HEX_MARK_VERT);
    (*_hori).initWithoutCalc(_game->board(), HEX_MARK_HORI);
  } else {
    assert(!(*_vert).stopped());
    assert(!(*_hori).stopped());
    if(_game->moves().size() > 0) {
      HexMove m = _game->moves()[_game->moves().size() - 1];
      (*_vert).moveWithoutCalc(m, true);
      (*_hori).moveWithoutCalc(m, true);
    }
  }
}

pair<bool, HexMove> SixPlayer::beginnerPlay()
{
  int n = _game->board().nMark();
  vector<unsigned> widths;
  if(n < 4) {
    widths.push_back(8);
  } else {
    widths.push_back(3);
    widths.push_back(3);
  }
  if(n < 4) {
    return commonPlay(-1, -1, 7, -1, 4, true, widths);
  } else {
    return commonPlay(-1, -1, 7, -1, 4, false, widths);
  }
}

pair<bool, HexMove> SixPlayer::intermediatePlay()
{
  int n = _game->board().nMark();
  vector<unsigned> widths;
  if(n < 4) {
    widths.push_back(10);
  } else {
    widths.push_back(4);
    widths.push_back(4);
    widths.push_back(4);
  }
  if(n < 4) {
    return commonPlay(-1, -1, 7, -1, 4, true, widths);
  } else {
    return commonPlay(-1, -1, 7, -1, 4, false, widths);
  }
}

pair<bool, HexMove> SixPlayer::advancedPlay()
{
  int n = _game->board().nMark();
  vector<unsigned> widths;
  if(n < 4) {
    widths.push_back(13);
  } else {
    widths.push_back(6);
    widths.push_back(6);
    widths.push_back(6);
  }
  if(n < 4) {
    return commonPlay(-1, -1, 10, -1, 4, true, widths);
  } else {
    return commonPlay(-1, -1, 7, -1, 4, false, widths);
  }
}

pair<bool, HexMove> SixPlayer::expertPlay()
{
  int n = _game->board().nMark();
  vector<unsigned> widths;
  if(n < 4) {
    widths.push_back(20);
  } else {
    widths.push_back(8);
    widths.push_back(8);
  }
  if(n < 4) {
    return commonPlay(-1, -1, 10, -1, 4, true, widths);
  } else {
    return commonPlay(3, -1, 7, -1, 4, true, widths);
  }
}

pair<bool, HexMove> SixPlayer::commonPlay(int smc, int hmc,
                                          int sms, int hms,
                                          int mio, bool ue,
                                          const vector<unsigned> &widths)
{
  pair<bool, HexMove> r(false, HexMove());
  if(_cancelMove)
    return r;
  HexMove m;
  _nNode = _nMove = _nCond = 0;
  if(_game->swappable() && ((*_game).board().nMark() == 0)) {
    m = makeSafeOpeningMove((*_game).board(), _game->next());
  } else if(_game->swappable() && ((*_game).board().nMark() == 1) &&
            swapValue((*_game).board()) == 1) {
    m = HexMove();
  } else {
    DBG << "Widths:";
    for(unsigned i = 0; i < widths.size(); i++) {
      DBG << " " << widths[i];
    }
    DBG << ", Connector: " << smc << "," << hmc << ","
        << sms << "," << hms << "," << mio << "," << ue << endl;
    updateConnectors(smc, hmc, sms, hms, mio, ue);
    if(_cancelMove)
      return r;
    (*_vert).calc();
    if(_cancelMove)
      return r;
    (*_hori).calc();
    if(_cancelMove)
      return r;
    double v = eval(_game->next(), *_vert, *_hori, &m, -HUGE_VAL, widths, 0);
    DBG << "v=" << v << endl;
    if(_cancelMove)
      return r;
  }

  if(!_vert.null())
    (*_vert).moveWithoutCalc(m, true);
  if(!_hori.null())
    (*_hori).moveWithoutCalc(m, true);
  DBG << "nNode=" << _nNode << ",nMove=" << _nMove << ",nCond=" << _nCond
      << endl;
  DBG << "Playing: ";
  (*_game).printMove(DBG, m);
  DBG << endl;
  return pair<bool, HexMove>(true, m);
}

HexMove SixPlayer::candidateMove() const
{
  if(_thinking)
    return _candidateMove;
  else
    return HexMove();
}
