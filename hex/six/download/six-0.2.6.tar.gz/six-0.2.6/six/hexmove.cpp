#include "hexmove.h"

#include <cassert>

HexMove::HexMove()
{
  _swap = true;
}

HexMove::HexMove(HexMark m, HexField f)
{
  _swap = false;
  _mark = m;
  _field = f;
}

bool HexMove::operator ==(const HexMove &m) const
{
  return ((_swap && m._swap) ||
          (!_swap && !m._swap && _mark == m._mark && _field == m._field));
}

bool HexMove::isSwap() const
{
  return _swap;
}

HexMark HexMove::mark() const
{
  assert(!_swap);
  return _mark;
}

HexField HexMove::field() const
{
  assert(!_swap);
  return _field;
}
