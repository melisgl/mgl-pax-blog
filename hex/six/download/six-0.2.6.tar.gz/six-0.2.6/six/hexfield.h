// Yo Emacs, this -*- C++ -*-
#ifndef HEXFIELD_H
#define HEXFIELD_H

/**
 * A field on the board.
 *
 * A field gets meaning in the context of a board's topology.
 */
typedef int HexField;

#endif
