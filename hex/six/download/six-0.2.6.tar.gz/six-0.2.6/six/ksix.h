// Yo Emacs, this -*- C++ -*-
#ifndef KSIX_H
#define KSIX_H

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif 

#include <kapp.h>
#include <kmainwindow.h>
#include <kaction.h>
#include <kprinter.h>

#include "poi.h"
#include "hexmatch.h"
#include "khexwidget.h"
#include "slicedtask.h"

/**
 * This class serves as the main window for six.  It handles the
 * menus, toolbars, status bars and acts as a classic bloated
 * controller.
 *
 * To avoid protability problems and dependency on qt compiled with thread
 * support, Connector is given the responsibility of invoking a SlicedTask
 * every now and then. This SlicedTask is a KSix object that does some
 * event processing and returns.
 */
class KSix : public KMainWindow, public SlicedTask
{
  Q_OBJECT
public:
  KSix();
  virtual ~KSix();
  void doSlice();
protected:
  void closeEvent(QCloseEvent *);
  /**
   * This function is called when it is time for the app to save its
   * properties for session management purposes.
   */
  void saveProperties(KConfig *);

  /**
   * This function is called when this app is restored.  The KConfig
   * object points to the session management config file that was saved
   * with @ref saveProperties
   */
  void readProperties(KConfig *);

private slots:
  void quit();
  // TO BE IMPLEMENTED:
//     void fileOpen();
//     void fileSave();
//     void fileSaveAs();
  void filePrint();

  void showToolbar();
  void showStatusbar();
  void configureKeys();
  void configureToolbars();

  void updateBoard();
  void updateActions();
  void updateClock();
  void updateMessage();
  void updateThinking();

  void turn();
  
  void gameNew();

  void gameBack();
  void gameForward();
  void gameSuspend();
  void gameResume();
  void gameSwap();

  void toggleSwap();
  void setBoardSize(int);
  void setBoardSizeByMenuItem(int item);

  void toggleNumbering();
  void toggleShowThinking();
  void setDisplayModeByMenuItem(int);

  void setBlackPlayerByMenuItem(int);
  void setWhitePlayerByMenuItem(int);

  void saveOptions();
  void readOptions();

  void clickLeft(HexField f);

  void handleStatusBarClick(int);
private:
  enum PlayerTypeT { PLAYER_NONE = -1, PLAYER_HUMAN,
                     PLAYER_BEGINNER, PLAYER_INTERMEDIATE,
                     PLAYER_ADVANCED, PLAYER_EXPERT};
  typedef enum PlayerTypeT PlayerType;

  void setupActions();

  HexPlayer *createPlayer(PlayerType p);
  void setBlack(PlayerType p, bool forceUpdate = false);
  void setWhite(PlayerType p, bool forceUpdate = false);
  HexMark onTurn();

  QString secToQString(int sec);

  static QString playerToString(PlayerType p);
  static PlayerType stringToPlayer(const QString &s);

  bool isThinking();
  void thinking(bool on);

  void setMatch();
  void flash();
private:
  Poi<HexMatch> _oldMatch;
  Poi<HexPlayer> _oldBlack;
  Poi<HexPlayer> _oldWhite;
  bool _updatePlayer;
  bool _stopGame;
  bool _thinking;
  HexMove _candidateMove;

  bool _swapAllowed;
  int _boardSize;
  PlayerType _blackPlayer, _whitePlayer;
  Poi<HexPlayer> _black;
  Poi<HexPlayer> _white;
  Poi<HexMatch> _match;
  KHexWidget *_hexWidget;
  
  KPrinter *_printer;

  // notable widgets on the statusbar
  QLabel *_blackClockMark;
  QLabel *_whiteClockMark;
  QLabel *_blackClockLabel;
  QLabel *_whiteClockLabel;

  //
  KToggleAction *_toolbarAction;
  KToggleAction *_statusbarAction;

  // file
  KAction *_gameNewAction;

  // game
  KAction *_gameBackAction;
  KAction *_gameForwardAction;
  KAction *_gameSuspendAction;
  KAction *_gameResumeAction;
  KAction *_gameHintAction;
  KAction *_gameSwapAction;
  KAction *_gameForceMoveAction;

  // game options
  KToggleAction *_toggleSwapAction;
  KSelectAction *_boardSizeAction;
  
  // display options
  KToggleAction *_toggleNumberingAction;
  KToggleAction *_showThinkingAction;
  KSelectAction *_displayModeAction;

  // players
  KSelectAction *_blackPlayerAction;
  KSelectAction *_whitePlayerAction;
};

#endif
