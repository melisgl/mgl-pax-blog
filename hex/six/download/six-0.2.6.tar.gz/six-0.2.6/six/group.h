// Yo Emacs, this -*- C++ -*-
#ifndef GROUP_H
#define GROUP_H

#include "hexboard.h"
#include "poi.h"

#include <utility>
#include <vector>

class Group;

/**
 * A home of @ref Group objects that together make up a segmentation of
 * the fields of a board position.
 */
class Grouping
{
  friend class GroupTest;
public:
  typedef int GroupIndex;
private:
  /**
   * RMap provides the reverse mapping: HexField to group indeces.
   */
  class RMap
  {
  public:
    RMap(int boardSize = 0);
    GroupIndex &operator [](HexField f);
    const GroupIndex &operator [](HexField f) const;
  private:
    vector<GroupIndex> _v;
  };
public:
  /**
   * Segments the fields of board <code>b</code> into groups.
   *
   * @param mark the mark of interest, fields with the opposite mark are
   * ignored; possible values are HEX_MARK_VERT and HEX_MARK_HORI.
   */
  void set(const HexBoard &b, HexMark mark);

  /**
   * Sets field <code>f</code> to the non-empty <code>mark</code>,
   * and updates the grouping. Unchanged groups are left alone, they
   * keep their addresses (thus the wrapping in Poi), but not their indeces
   * in the grouping.
   *
   * If necessary a new group is created and is returned as the
   * <code>first</code> member of the return value.
   *
   * Obsolete groups - such as the group with the single empty
   * field on which the move was made and groups becoming adjacent to the
   * new group - are deleted. These deleted groups are returned as
   * the <code>second</code> member of the return value. The first
   * of the obsolete groups is always the one with the field on which the
   * move was made.
   */
  pair<Poi<Group>, vector<Poi<Group> > > move(HexField f, HexMark mark);

  /**
   * @return the number of groups in this grouping
   */
  int size() const;

  /**
   * @param i is the index of the group; it must be in the range [0, size())
   *
   * @return the group of index <code>i</code>
   */
  Poi<Group> operator [](GroupIndex i) const;

  /**
   * @return the index of the group field <code>f</code> belongs to;
   * or <code>-1</code> if it does not belong to any group.
   */
  GroupIndex operator ()(HexField f) const;

  /**
   * @return the index of group <code>g</code> in this grouping;
   */
  GroupIndex groupIndex(const Group *g) const;

  /**
   * @return the board that is segmented
   */
  const HexBoard &board() const;

  /**
   * @return the mark of interest
   */
  HexMark mark() const;
private:
  HexBoard _board;
  HexMark _mark;
  vector<Poi<Group> > _groups;
  RMap _rmap;
};

/**
 * A group is a set of adjacent fields with the same mark.
 * If the mark is empty then the group has exactly one field in it,
 * if the mark is non-empty then the group is maximal in the sense
 * that all fields adjacent to it are of different mark.
 *
 * Groups are immutable objects and always constructed by the
 * @ref Grouping they belong to.
 *
 * Groups always contain at least one field.
 */
class Group
{
  friend Grouping;
  friend GroupTest;
public:
  /**
   * The mark of the group.
   */
  HexMark mark() const;

  /**
   * @return true iff this group includes an edge
   */
  bool edge() const;

  /**
   * @return the sum of the area of fields in this group;
   * every normal field has an area of 1,
   * edge fields have an area equal to the width or height of the board
   * dependig on their orientation.
   */
  int area() const;

  /**
   * @return the fields in this group
   */
  const vector<HexField> &fields() const;

  /**
   * Prints the group.
   */
  friend ostream &operator <<(ostream &os, const Group &g);
private:
  Group(Grouping::GroupIndex gi, const HexBoard &b, HexField f,
        Grouping::RMap *rmap);
  Group(Grouping::GroupIndex gi, const HexBoard &b, HexMark m,
        Grouping::RMap *rmap,
        const vector<Poi<Group> > &groups);
  void add(Grouping::GroupIndex gi,const HexBoard &b, HexField f,
           Grouping::RMap *rmap);
  void expand(Grouping::GroupIndex gi,const HexBoard &b, HexField f,
              Grouping::RMap *rmap);
  HexMark _mark;
  vector<HexField> _fields;
  bool _edge;
  int _area;
};

#endif
