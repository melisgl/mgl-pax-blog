#include "carrier.h"

#include <algorithm>

#define N_INT_BITS (sizeof(unsigned int) * 8)

Carrier::Carrier()
{
  for(unsigned i = 0; i < VSIZE; i++) {
    _v[i] = 0;
  }
  _size = 0;
}

Carrier::Carrier(const Carrier &c)
{
  for(unsigned i = 0; i < VSIZE; i++) {
    _v[i] = c._v[i];
  }
  _size = c._size;
}

Carrier &Carrier::operator =(const Carrier &c)
{
  for(unsigned i = 0; i < VSIZE; i++) {
    _v[i] = c._v[i];
  }
  _size = c._size;
  return *this;
}

bool Carrier::operator ==(const Carrier &c) const
{
  for(unsigned i = 0; i < VSIZE; i++) {
    if(_v[i] != c._v[i]) {
      return false;
    }
  }
  return true;
}

bool Carrier::operator <(const Carrier &c) const
{
  for(unsigned i = 0; i < VSIZE; i++) {
    if(_v[i] >= c._v[i]) {
      return false;
    }
  }
  return true;
}

bool Carrier::includes(const Carrier &c) const
{
  for(unsigned i = 0; i < VSIZE; i++) {
    if(c._v[i] & ~_v[i]) {
      return false;
    }
  }
  return true;
}

bool Carrier::empty() const
{
  for(unsigned i = 0; i < VSIZE; i++) {
    if(_v[i])
      return false;
  }
  return true;
}

#define MASK_01010101 (((unsigned int)(-1))/3)
#define MASK_00110011 (((unsigned int)(-1))/5)
#define MASK_00001111 (((unsigned int)(-1))/17)

static int nifty_bitcount(unsigned int n)
{
  n = (n & MASK_01010101) + ((n >> 1) & MASK_01010101);
  n = (n & MASK_00110011) + ((n >> 2) & MASK_00110011);
  n = (n & MASK_00001111) + ((n >> 4) & MASK_00001111);
  return n % 255 ;
}

int Carrier::size() const
{
  if(_size < 0) {
    // bypass const protection with vengeance
    int *s = (int *)&_size;
    *s = 0;
    for(unsigned i = 0; i < VSIZE; i++) {
      (*s) += nifty_bitcount(_v[i]);
    }
  }
  return _size;
}

int Carrier::limit() const
{
  return N_INT_BITS * VSIZE;
}

void Carrier::addField(int field)
{
  assert(field >= 0);
  unsigned int i = field / N_INT_BITS;
  unsigned int b = (1 << (field - i * N_INT_BITS));
  assert(i < VSIZE);
  _v[i] |= b;
  _size = -1;
}

void Carrier::removeField(int field)
{
  assert(field >= 0);
  unsigned int i = field / N_INT_BITS;
  unsigned int b = (1 << (field - i * N_INT_BITS));
  assert(i < VSIZE);
  _v[i] &= (~b);
  _size = -1;
}

bool Carrier::has(int field) const
{
  if(field < 0) {
    return false;
  } else {
    unsigned int i = field / N_INT_BITS;
    unsigned int b = (1 << (field - i * N_INT_BITS));
    assert(i < VSIZE);
    return _v[i] & b;
  }
}

const vector<int> Carrier::fields() const
{
  vector<int> r;
  for(unsigned i = 0; i < VSIZE; i++) {
    for(unsigned b = 0; b < N_INT_BITS; b++) {
      if(_v[i] & (1 << b)) {
        r.push_back(i * N_INT_BITS + b);
      }
    }
  }
  return r;
}

Carrier &Carrier::unite(const Carrier &c)
{
  for(unsigned i = 0; i < VSIZE; i++) {
    _v[i] |= c._v[i];
  }
  _size = -1;
  return *this;
}

Carrier &Carrier::intersect(const Carrier &c)
{
  for(unsigned i = 0; i < VSIZE; i++) {
    _v[i] &= c._v[i];
  }
  _size = -1;
  return *this;
}

bool Carrier::disjunct(const Carrier &c) const
{
  for(unsigned i = 0; i < VSIZE; i++) {
    if(_v[i] & c._v[i]) {
      return false;
    }
  }
  return true;
}

ostream &operator <<(ostream &os, const Carrier &c)
{
  vector<int> v;
  for(unsigned i = 0; i < Carrier::VSIZE; i++) {
    for(unsigned b = 0; b < N_INT_BITS; b++) {
      if(c._v[i] & (1 << b)) {
        v.push_back(i * N_INT_BITS + b);
      }
    }
  }
  os << "[";
  for(unsigned int i = 0; i < v.size(); i++) {
    if(i)
      os << ",";
    os << v[i];
  }
  os << "]";
  return os;
}
