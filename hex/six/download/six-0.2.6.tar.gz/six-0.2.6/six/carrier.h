// Yo Emacs, this -*- C++ -*-
#ifndef CARRIER_H
#define CARRIER_H

#include <vector>

/**
 * A carrier is a set of empty fields on a board that is
 * between the two ends of a @ref SubGame.
 * It "carries" the connection between the ends.
 *
 * It is just a set of integers, this implementation is intended to be
 * lightweight and specialized for the needs of this application.
 *
 * The size of the set is fixed: see @ref limit().
 */
class Carrier
{
public:
  /**
   * Constructs an empty carrier.
   */
  Carrier();

  /**
   * Copy constructor.
   */
  Carrier(const Carrier &c);

  /**
   * Assigns <code>c</code> to this carrier and returns a reference to this
   * carrier.
   */
  Carrier &operator =(const Carrier &c);

  /**
   * Tests if this carrier is equal to <code>c</code>.
   * Two carriers are equal iff they contain the exact same fields.
   */
  bool operator ==(const Carrier &c) const;

  /**
   * Perfroms lexicographical comparison of the sorted lists of fields
   * in the two carriers.
   * Handy for use in sorted containers such as STL sets, maps.
   *
   * @return true iff this carrier is less than <code>c</code>.
   */
  bool operator <(const Carrier &c) const;

  /**
   * Tests if this carrier - as a set - includes <code>c</code>.
   */
  bool includes(const Carrier &c) const;

  /**
   * Tests if this carrier is empty.
   */
  bool empty() const;

  /**
   * Returns the number of fields in this carrier.
   *
   * When called first this method is a bit expensive,
   * subsequent calls a very cheap.
   */
  int size() const;

  /**
   * The upper limit for fields that can be stored in this carrier.
   * Valid fields are the integers in the [0, limit()) range.
   */
  int limit() const;

  /**
   * Adds a fields to this carrier.
   */
  void addField(int field);

  /**
   * Removes a fields from this carrier.
   */
  void removeField(int field);

  /**
   * Tests if <code>field</code> is in this carrier.
   */
  bool has(int field) const;

  /**
   * Constructs a vector of fields from the fields in this carrier.
   */
  const vector<int> fields() const;

  /**
   * Calculates the union of this carrier and <code>c</code> in place.
   *
   * @return reference to this carrier
   */
  Carrier &unite(const Carrier &c);

  /**
   * Calculates the intersection of this carrier and <code>c</code> in place.
   *
   * @return reference to this carrier
   */
  Carrier &intersect(const Carrier &c);

  /**
   * Checks if this carrier and <code>c</code> are disjunct.
   */
  bool disjunct(const Carrier &c) const;

  /**
   * Writes <code>c</code> in the form of <code>[0,3,4,7]</code>
   * to <code>os</code>.
   */
  friend ostream &operator <<(ostream &os, const Carrier &c);
private:
  static const unsigned int VSIZE = 4;
  unsigned int _v[VSIZE];
  // The result of the last size() calculation is in _size,
  // if there was no size() call or the carrier was modified
  // since then it is negative.
  int _size;
};

#endif
