#include "hexmatch.h"
#include "poi.h"

#include <algorithm>
#include <sys/time.h>
#include <cassert>

HexMatch::HexMatch(const HexGame &g, const Poi<HexPlayer> &vert,
                   const Poi<HexPlayer> &hori)
  : _game(g), _vertNew(0), _horiNew(0), _status(MATCH_OFF)
{
  setVerticalPlayer(vert);
  setHorizontalPlayer(hori);
  resetClock();
  connect(&_timer, SIGNAL(timeout()), this, SLOT(timerDone()));
}

void HexMatch::setVerticalPlayer(const Poi<HexPlayer> &vert)
{
  if(_vert != vert) {
    _vert = vert;
    _vertNew = true;
    emit signalPlayerChange();
  }
}

void HexMatch::setHorizontalPlayer(const Poi<HexPlayer> &hori)
{
  if(_hori != hori) {
    _hori = hori;
    _horiNew = true;
    emit signalPlayerChange();
  }
}

const HexGame &HexMatch::game() const
{
  return _game;
}

pair<long, long> HexMatch::vertClockSum() const
{
  pair<long, long> r;
  r.first = 0;
  r.second = 0;
  for(unsigned i = 0; i < _vertClock.size(); i++) {
    r.first += _vertClock[i].first;
    r.second += _vertClock[i].second;
  }
  return r;
}

pair<long, long> HexMatch::horiClockSum() const
{
  pair<long, long> r;
  r.first = 0;
  r.second = 0;
  for(unsigned i = 0; i < _horiClock.size(); i++) {
    r.first += _horiClock[i].first;
    r.second += _horiClock[i].second;
  }
  return r;
}

pair<long, long> HexMatch::vertClockTotal() const
{
  pair<long, long> r = _millisecondsVertTotal;
  if(_game.next() == HEX_MARK_VERT) {
    r.first += _millisecondsMove.first;
    r.second += _millisecondsMove.second;
  }
  return r;
}

pair<long, long> HexMatch::horiClockTotal() const
{
  pair<long, long> r = _millisecondsHoriTotal;
  if(_game.next() == HEX_MARK_HORI) {
    r.first += _millisecondsMove.first;
    r.second += _millisecondsMove.second;
  }
  return r;
}

const vector<pair<long, long> > &HexMatch::vertClock() const
{
  return _vertClock;
}

const vector<pair<long, long> > &HexMatch::horiClock() const
{
  return _horiClock;
}

bool HexMatch::doSome()
{
  assert(!_vert.null());
  assert(!_hori.null());
  assert(_game.board().winner() == HEX_MARK_EMPTY);
  assert(_status != MATCH_FINISHED);
  setStatus(MATCH_ON);
  if(_vertNew) {
    (*_vert).init(&_game, HEX_MARK_VERT);
    _vertNew = 0;
  }
  if(_horiNew) {
    (*_hori).init(&_game, HEX_MARK_HORI);
    _horiNew = 0;
  }
  pair<bool, HexMove> move;
  bool valid = 0;
  while(!valid) {
    if(_game.next() == HEX_MARK_VERT) {
      move = (*_vert).play();
    } else {
      move = (*_hori).play();
    }
    valid = !move.first || _game.isValidMove(move.second);
  }
  if(move.first) {
    clockOff();
    pair<long, long> t;
    t.first = _millisecondsMove.first;
    t.second = _millisecondsMove.second;
    if(_game.next() == HEX_MARK_VERT) {
      _vertClock.push_back(t);
      _horiClock.push_back(pair<long, long>(0, 0));
    } else {
      _horiClock.push_back(t);
      _vertClock.push_back(pair<long, long>(0, 0));
    }
    _game.play(move.second);
    _forwardMoves.clear();
    _forwardVertClock.clear();
    _forwardHoriClock.clear();
    if(_game.board().winner() != HEX_MARK_EMPTY) {
      setStatus(MATCH_FINISHED);
    } else {
      resetClock();
      clockOn();
    }
    emit signalClockChange();
    emit signalPositionChange();
  }
  return move.first;
}

void HexMatch::on()
{
  if(_status == MATCH_OFF)
    setStatus(MATCH_ON);
}

void HexMatch::off()
{
  if(_status == MATCH_ON)
    setStatus(MATCH_OFF);
}

HexMatch::Status HexMatch::status() const
{
  return _status;
}

void HexMatch::setStatus(Status status)
{
  if(_status != status) {
    _status = status;
    if(status == MATCH_ON)
      clockOn();
    else
      clockOff();
    emit signalStatusChange();
  }
}

bool HexMatch::canBack() const
{
  assert(_game.moves().size() == _vertClock.size());
  assert(_game.moves().size() == _horiClock.size());
  return !_game.moves().empty();
}

void HexMatch::back()
{
  assert(canBack());
  _vertNew = 1;
  _horiNew = 1;
  _forwardMoves.push_front(_game.unplay());
  _forwardVertClock.push_front(_vertClock.back());
  _vertClock.pop_back();
  _forwardHoriClock.push_front(_horiClock.back());
  _horiClock.pop_back();
  setStatus(MATCH_OFF);
  resetClock();
  emit signalClockChange();
  emit signalPositionChange();
}

bool HexMatch::canForward() const
{
  assert(_forwardMoves.size() == _forwardVertClock.size());
  assert(_forwardMoves.size() == _forwardHoriClock.size());
  return !_forwardMoves.empty();
}

void HexMatch::forward()
{
  assert(canForward());
  _vertNew = 1;
  _horiNew = 1;
  _game.play(_forwardMoves.front());
  _forwardMoves.pop_front();
  _vertClock.push_back(_forwardVertClock.front());
  _forwardVertClock.pop_front();
  _horiClock.push_back(_forwardHoriClock.front());
  _forwardHoriClock.pop_front();
  if(_game.board().winner() == HEX_MARK_EMPTY) {
    setStatus(MATCH_OFF);
  } else {
    setStatus(MATCH_FINISHED);
  }
  resetClock();
  emit signalClockChange();
  emit signalPositionChange();
}

void HexMatch::resetClock()
{
  _millisecondsMove.first = 0;
  _millisecondsMove.second = 0;
  _millisecondsVertTotal = vertClockSum();
  _millisecondsHoriTotal = horiClockSum();
}

void HexMatch::clockOn()
{
  assert(_status == MATCH_ON);
  _timer.start(250);
  _startClock = clock();
  gettimeofday(&_startTime, 0);
}

void HexMatch::clockOff()
{
  _timer.stop();
  // update procsessor time
  clock_t endClock;
  endClock = clock();
  _millisecondsMove.first += ((long)endClock - (long)_startClock) / 1000;
  // update real time
  struct timeval endTime;
  gettimeofday(&endTime, 0);
  _millisecondsMove.second += 1000 * (endTime.tv_sec - _startTime.tv_sec) +
    (endTime.tv_usec - _startTime.tv_usec) / 1000;
}

void HexMatch::timerDone()
{
  clockOff();
  clockOn();
  emit signalClockChange();
}

ostream &operator <<(ostream &os, const HexMatch &b)
{
  os << b.game();
  return os;
}

#include "hexmatch.moc"
