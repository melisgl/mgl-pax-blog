#include "connector.h"
#include "misc.h"

#include <cassert>
#include <cmath>
#include <algorithm>

#ifdef NDEBUG
#define OFF 0
#define ON 0
#else
#define OFF 0
#define ON 0
#endif

#define LOG_ENQUEUE ON
#define LOG_ADD_CONN ON
#define LOG_ADD_SEMI ON
#define LOG_MINIMIZE_CONN ON
#define LOG_MINIMIZE_SEMI ON
#define LOG_PROCESS_CONN ON
#define LOG_PROCESS_SEMI ON
#define LOG_UPDATE_CONN ON
#define LOG_UPDATE_SEMI ON
#define LOG_CALC ON
#define LOG_CALC_STATS ON
#define LOG_WIN ON

//
//
//

Connector::ConnKey::ConnKey(Group *group)
{
  _group = group;
}

Group *Connector::ConnKey::group() const
{
  return _group;
}

bool Connector::ConnKey::operator <(const Connector::ConnKey &s) const
{
  return _group < s._group;
}

bool Connector::ConnKey::operator ==(const Connector::ConnKey &s) const
{
  return _group == s._group;
}

//
//
//

Connector::Conn2Key::Conn2Key(Group *g0, Group *g1)
{
  _start = MIN(g0, g1);
  _end = MAX(g0, g1);
}

Group *Connector::Conn2Key::start() const
{
  return _start;
}

Group *Connector::Conn2Key::end() const
{
  return _end;
}

bool Connector::Conn2Key::operator <(const Connector::Conn2Key &s) const
{
  return (_start < s._start || (_start == s._start && _end < s._end));
}

bool Connector::Conn2Key::operator ==(const Connector::Conn2Key &s) const
{
  return (_start == s._start && _end == s._end);
}

//
//
//

Connector::Connector(int softMaxConn, int hardMaxConn,
                     int softMaxSemi, int hardMaxSemi,
                     int maxInOrRule, bool useEdge )
{
  _stop = false;
  _task = 0;

  _softMaxConn = softMaxConn;
  _hardMaxConn = hardMaxConn;
  _softMaxSemi = softMaxSemi;
  _hardMaxSemi = hardMaxSemi;
  _maxInOrRule = maxInOrRule;
  _useEdge = useEdge;
}

Connector::Connector(const Connector &c)
{
  assert(!c._stop);
  _stop = false;
  _task = 0;

  _softMaxConn = c._softMaxConn;
  _hardMaxConn = c._hardMaxConn;
  _softMaxSemi = c._softMaxSemi;
  _hardMaxSemi = c._hardMaxSemi;
  _maxInOrRule = c._maxInOrRule;
  _useEdge = c._useEdge;

  _groups = c._groups;
  assert(c._subgameQueue.empty());
  //_connFanMap remains empty for a while
  _connMap = c._connMap;
  _semiMap = c._semiMap;
  _winner = c._winner;
  _potentialWinner = c._potentialWinner;

  {
    ConnBatchMap::iterator cur = _connMap.begin();
    ConnBatchMap::iterator end = _connMap.end();
    ConnBatch::iterator setcur, setend;
    while(cur != end) {
      ConnBatch &s = (*cur).second;
      setcur = s.begin();
      setend = s.end();
      while(setcur != setend) {
        *setcur = Poi<SubGame>(new SubGame(**setcur));
        addToConnFanMap(&**setcur);
        setcur++;
      }
      cur++;
    }
  }

  {
    SemiBatchMap::iterator cur = _semiMap.begin();
    SemiBatchMap::iterator end = _semiMap.end();
    SemiBatch::iterator setcur;
    SemiBatch::iterator setend;
    while(cur != end) {
      SemiBatch &s = (*cur).second;
      setcur = s.begin();
      setend = s.end();
      while(setcur != setend) {
        if(!(**setcur).processed()) {
          *setcur = Poi<SubGame>(new SubGame(**setcur));
        }
        setcur++;
      }
      cur++;
    }
  }
}

void Connector::setTask(SlicedTask *task)
{
  _task = task;
}

void Connector::stop()
{
  _stop = true;
}

bool Connector::stopped() const
{
  return _stop;
}

int Connector::softMaxConn() const
{
  return _softMaxConn;
}

int Connector::hardMaxConn() const
{
  return _hardMaxConn;
}

int Connector::softMaxSemi() const
{
  return _softMaxSemi;
}

int Connector::hardMaxSemi() const
{
  return _hardMaxSemi;
}

int Connector::maxInOrRule() const
{
  return _maxInOrRule;
}

bool Connector::useEdge() const
{
  return _useEdge;
}

void Connector::enqueue(const Poi<SubGame> &sg)
{
#if LOG_ENQUEUE
  cout << "Enqueue: " << *sg << endl;
#endif
  assert((*sg).waiting());
  _subgameQueue.push_back(sg);
  (*sg).setEnqueued();
}

bool Connector::addConn(const Poi<SubGame> &conn)
{
  assert(!(*conn).semi());
  Conn2Key wb((*conn).x(), (*conn).y());
  ConnBatch &s = _connMap[wb];
  if(_hardMaxConn >= 0 && s.size() >= (unsigned)_hardMaxConn) {
#if LOG_ADD_CONN
    cout << "Conn prune: " << *conn << endl;
#endif
    return true;
  } else {
#if LOG_ADD_CONN
    cout << "Adding conn: " << *conn << endl;
#endif
    int ss = (*conn).carrier().size();
    int n = 0;
    ConnBatch::iterator cur = s.begin();
    ConnBatch::iterator end = s.end();
    while(cur != end && ss >= (**cur).carrier().size()) {
      cur++;
      n++;
    }
    s.insert(cur, conn);
    if(!(*conn).processed()) {
      if(_softMaxConn < 0 || n < _softMaxConn) {
        enqueue(conn);
      }
    }

    // Alternative impl: this code segment doesn't keep the batch sorted
//     if(!(*conn).processed()) {
//       s.push_back(conn);
//       if(_softMaxConn < 0 || s.size() < (unsigned)_softMaxConn) {
//         enqueue(conn);
//       }
//     } else {
//       s.push_front(conn);
//     }
    setPotentialWinner(*conn);
    addToConnFanMap(&*conn);
    return true;
  }
}

bool Connector::addSemi(const Poi<SubGame> &semi)
{
  assert((*semi).semi());
  Conn2Key k((*semi).x(), (*semi).y());
  SemiBatch &s = _semiMap[k];
  if(_hardMaxSemi >= 0 && s.size() >= (unsigned)_hardMaxSemi) {
#if LOG_ADD_SEMI
    cout << "Semi prune:" << *semi << endl;
#endif
    return true;
  } else {
#if LOG_ADD_SEMI
    cout << "Adding semi: " << *semi << endl;
#endif
    int ss = (*semi).carrier().size();
    int n = 0;
    SemiBatch::iterator cur = s.begin();
    SemiBatch::iterator end = s.end();
    while(cur != end && ss >= (**cur).carrier().size()) {
      cur++;
      n++;
    }
    s.insert(cur, semi);
    if(!(*semi).processed()) {
      if(_softMaxSemi < 0 || n < _softMaxSemi) {
        enqueue(semi);
      }
    }

    // Alternative impl: this code segment doesn't keep the batch sorted
//     if(!(*semi).processed()) {
//       s.push_back(semi);
//       if(_softMaxSemi < 0 || s.size() < (unsigned)_softMaxSemi) {
//         enqueue(semi);
//       }
//     } else {
//       s.push_front(semi);
//     }

    return true;
  }
}

bool Connector::minimizeConns(const SubGame &g,
                              bool checkParamMinimality,
                              bool tryToEnqueue)
{
  Conn2Key k(g.x(), g.y());
  ConnBatchMap::iterator vci = _connMap.find(k);
  if(vci != _connMap.end()) {
    ConnBatch &vc = (*vci).second;
    ConnBatch::iterator cur = vc.begin();
    ConnBatch::iterator end = vc.end();
    ConnBatch::iterator next;
    int n = 0, d = 0;
    while(cur != end) {
      next = cur;
      ++next;
      if(checkParamMinimality && g.includes(**cur)) {
        assert(d == 0);
#if LOG_MINIMIZE_CONN
        cout << g << " fatter than conn " << **cur << endl;
#endif
        return false;
      }
      if((**cur).includes(g)) {
#if LOG_MINIMIZE_CONN
        cout << "Old conn " << **cur << " fatter than " << g << endl;
#endif
        removeFromConnFanMap(&**cur);
        (**cur).setProcessed();
        vc.erase(cur);
        d++;
      } else {
        if(tryToEnqueue && n < _softMaxConn && (**cur).waiting()) {
          enqueue(*cur);
        }
      }
      cur = next;
      n++;
    }
    if(vc.empty())
      _connMap.erase(vci);
  }
  return true;
}

bool Connector::minimizeSemis(const SubGame &g,
                              bool checkParamMinimality,
                              bool tryToEnqueue)
{
  Conn2Key k(g.x(), g.y());
  SemiBatchMap::iterator vci = _semiMap.find(k);
  if(vci != _semiMap.end()) {
    SemiBatch &vc = (*vci).second;
    SemiBatch::iterator cur = vc.begin();
    SemiBatch::iterator end = vc.end();
    SemiBatch::iterator next;
    int n = 0, d = 0;
    while(cur != end) {
      next = cur;
      ++next;
      if(d == 0 && checkParamMinimality && g.includes(**cur)) {
#if LOG_MINIMIZE_SEMI
        cout << g << " fatter than semi " << **cur << endl;
#endif
        return false;
      }
      if((**cur).includes(g)) {
#if LOG_MINIMIZE_SEMI
        cout << "Old semi " << **cur << " fatter than " << g << endl;
#endif
        (**cur).setProcessed();
        vc.erase(cur);
        d++;
      } else {
        if(tryToEnqueue && n < _softMaxSemi && (**cur).waiting()) {
          enqueue(*cur);
        }
      }
      cur = next;
      n++;
    }
    if(vc.empty())
      _semiMap.erase(vci);
  }
  return true;
}

bool Connector::tryToAddConn(const Poi<SubGame> &pg)
{
  assert(!(*pg).semi());
  const SubGame &g = *pg;
#if LOG_ADD_CONN
  cout << "About to add conn: " << g << endl; }
#endif
  if(!minimizeConns(g, true, true)) {
    return false;
  }
  if(addConn(pg)) {
    minimizeSemis(g, false, true);
    return true;
  } else {
    return false;
  }
}

bool Connector::tryToAddSemi(const Poi<SubGame> &pg)
{
  assert((*pg).semi());
  const SubGame &g = *pg;
#if LOG_ADD_SEMI
  cout << "About semi: " << g << endl;
#endif
  if(includesAnyConn(g)) {
    return false;
  }
  if(!minimizeSemis(g, true, true)) {
    return false;
  }
  return addSemi(pg);
}

bool Connector::includesAnyConn(const SubGame &g)
{
  Conn2Key wb(g.x(), g.y());
  ConnBatchMap::iterator ci = _connMap.find(wb);
  if(ci != _connMap.end()) {
    ConnBatch &c = (*ci).second;
    ConnBatch::iterator cur = c.begin();
    ConnBatch::iterator end = c.end();
    while(cur != end) {
      if(g.includes(**cur)) {
        return true;
      }
      ++cur;
    }
  }
  return false;
}

void Connector::addToConnFanMap(const SubGame *sg)
{
  ConnKey ckx(sg->x());
  ConnKey cky(sg->y());
  ConnFan &x = _connFanMap[ckx];
  ConnFan &y = _connFanMap[cky];
  x.push_back(sg);
  y.push_back(sg);
}

void Connector::removeFromConnFanMap(const SubGame *sg)
{
  ConnFan::iterator cur;
  ConnFan::iterator prev;
  ConnFan::iterator end;

  ConnKey ckx((*sg).x());
  ConnFanMap::iterator xsi = _connFanMap.find(ckx);
  if(xsi != _connFanMap.end()) {
    ConnFan &xs = _connFanMap[ckx];
    cur = xs.begin();
    prev = end = xs.end();
    while(cur != end) {
      if(*cur == sg) {
        xs.erase(cur);
        break;
      }
      prev = cur;
      ++cur;
    }
    if(xs.empty()) {
      _connFanMap.erase(xsi);
    }
  }

  ConnKey cky((*sg).y());
  ConnFanMap::iterator ysi = _connFanMap.find(cky);
  if(ysi != _connFanMap.end()) {
    ConnFan &ys = _connFanMap[cky];
    cur = ys.begin();
    prev = end = ys.end();
    while(cur != end) {
      if(*cur == sg) {
        ys.erase(cur);
        break;
      }
      prev = cur;
      ++cur;
    }
    if(ys.empty()) {
      _connFanMap.erase(ysi);
    }
  }
}

void Connector::processConn(const SubGame &conn)
{
#if LOG_PROCESS_CONN
  cout << "Processing conn " << conn << endl << endl;
#endif
  assert(!conn.processed());
  ConnKey ckx(conn.x());
  ConnFanMap::iterator xi = _connFanMap.find(ckx);
  if(xi != _connFanMap.end()) {
    ConnFan &c = (*xi).second;
    ConnFan::iterator cur = c.begin();
    ConnFan::iterator end = c.end();
    while(cur != end) {
      if((**cur).processed()) {
        applyAnd(conn, **cur);
      }
      ++cur;
    }
  }
  ConnKey cky(conn.y());
  ConnFanMap::iterator yi = _connFanMap.find(cky);
  if(yi != _connFanMap.end()) {
    ConnFan &c = (*yi).second;
    ConnFan::iterator cur = c.begin();
    ConnFan::iterator end = c.end();
    while(cur != end) {
      if((**cur).processed()) {
        applyAnd(conn, **cur);
      }
      ++cur;
    }
  }
}

// class SubGamePointerCarrierIntersectionComparator
// {
// public:
//   SubGamePointerCarrierIntersectionComparator(const Carrier &c) : _c(c)
//   {
//   }

//   bool operator ()(const SubGame *s0, const SubGame *s1) const
//   {
//     Carrier i0(_c);
//     i0.intersect(s0->carrier());
//     Carrier i1(_c);
//     i1.intersect(s1->carrier());
//     if(i0.size() < i1.size()) {
//       return true;
//     } else if(i0.size() > i1.size()) {
//       return false;
//     } else {
//       return s0->carrier().size() < s1->carrier().size();
//     }
//   }
// private:
//   const Carrier &_c;
// };

void Connector::processSemi(const SubGame &semi)
{
#if LOG_PROCESS_SEMI
  cout << "Processing semi " << semi << endl << endl;
#endif
  assert(!semi.processed());
  vector<const SubGame *> semis = semisWithSamePath(&semi);
  // it seems that if the semis are sorted by carrier size
  // this sort is not worth it:
  //   sort(semis.begin(), semis.end(),
  //        SubGamePointerCarrierIntersectionComparator(semi.carrier()));
#if LOG_PROCESS_SEMI
  cout << "Apply or: " << semi << endl;
  cout << "S=" << semis.size() << endl;
  for(unsigned q = 0; q < semis.size(); q++) {
    cout << *semis[q] << endl;
  }
#endif
  int s = ((_maxInOrRule < 0) ? (semis.size() + 1) : _maxInOrRule);
  vector<Carrier> intersections(s);
  vector<Carrier> unions(s);
  intersections[0] = semi.carrier();
  unions[0] = semi.carrier();
  applyOr(semi.x(), semi.y(), semis, 0, intersections, unions, 1);
#if LOG_PROCESS_SEMI
  cout << "Apply or done" << endl;
#endif
}

void Connector::applyAnd(const SubGame &s0, const SubGame &s1)
{
  Group *x, *y, *g;
#if LOG_PROCESS_CONN
  cout << "applyAnd: " << s0 << endl;
#endif
  if(s0.concatable(s1, &x, &y, &g) && (_useEdge || !g->edge()) &&
     !s0.carrier().has(y->fields()[0]) && !s1.carrier().has(x->fields()[0]) &&
     s0.carrier().disjunct(s1.carrier())) {
    Poi<SubGame> sg(new SubGame(s0, s1));
    if(g->mark() != HEX_MARK_EMPTY) {
#if LOG_PROCESS_CONN
      cout << "CONN: " << s0 << " & " << s1 << " = " << *sg << endl;
#endif
      tryToAddConn(sg);
    } else {
#if LOG_PROCESS_CONN
      cout << "SEMI: " << s0 << " & " << s1 << " = " << *sg << endl;
#endif
      tryToAddSemi(sg);
    }
  }
}

void Connector::applyOr(Group *x, Group *y,
                         const vector<const SubGame *> &semis, int semiOffset,
                         vector<Carrier> &un, vector<Carrier> &in,
                         int depth)
{
  if(_maxInOrRule < 0 || depth < _maxInOrRule) {
    while((unsigned)semiOffset < semis.size()) {
      in[depth] = in[depth - 1];
      in[depth].intersect(semis[semiOffset]->carrier());
      if(in[depth].empty()) {
        un[depth] = un[depth - 1];
        un[depth].unite(semis[semiOffset]->carrier());
#if LOG_PROCESS_SEMI
        cout << "ORING NEW:(" << depth << ", " << semiOffset << ")" << endl;
        cout << " OR: adding: " << SubGame(x, y, un[depth]) << endl;
#endif
        tryToAddConn(new SubGame(x, y, un[depth]));
      } else {
        if(_maxInOrRule < 0 || depth + 1 < _maxInOrRule &&
           !(in[depth] == in[depth - 1])) {
#if LOG_PROCESS_SEMI
          cout << "ORING:(" << depth << ", "
               << semiOffset << ")" << in[depth] << endl;
#endif
          un[depth] = un[depth - 1];
          un[depth].unite(semis[semiOffset]->carrier());
          applyOr(x, y, semis, semiOffset + 1, un, in, depth + 1);
        }
      }
      semiOffset++;
    }
  }
}

vector<const SubGame *> Connector::semisWithSamePath(const SubGame *sg)
{
  Conn2Key k(sg->x(), sg->y());
  SemiBatch &vc = _semiMap[k];
  assert(!vc.empty());
  SemiBatch::iterator cur = vc.begin();
  SemiBatch::iterator end = vc.end();
  vector<const SubGame *> r;
  while(cur != end && r.size() < (unsigned)_softMaxSemi) {
    if(&**cur != sg && (**cur).processed()) {
      r.push_back(&**cur);
    }
    ++cur;
  }
  return r;
}

void Connector::init(const HexBoard &b, HexMark mark)
{
  initWithoutCalc(b, mark);
  calc();
}

void Connector::initWithoutCalc(const HexBoard &b, HexMark mark)
{
  assert(mark == HEX_MARK_VERT || mark == HEX_MARK_HORI);
  Group *fGroup;
  Group *neighbourGroup;
  const Carrier emptyCarrier;
  _groups.set(b, mark);
  _subgameQueue.clear();
  _connFanMap.clear();
  _connMap.clear();
  _semiMap.clear();
  _potentialWinner = _winner = b.winner();
  if(_winner == HEX_MARK_EMPTY) {
    for(HexField f = HexBoard::FIRST_NORMAL_FIELD; f < b.size(); f++) {
      if(b.get(f) == HEX_MARK_EMPTY) {
        Grouping::GroupIndex fgi = _groups(f);
        if(fgi >= 0) {
          fGroup = &*_groups[fgi];
          HexBoard::Iterator neighbour = b.neighbourBegin(f);
          while(neighbour != b.neighbourEnd()) {
            Grouping::GroupIndex ngi = _groups(*neighbour);
            if(ngi >= 0) {
              neighbourGroup = &*_groups[ngi];
              tryToAddConn(new SubGame(fGroup, neighbourGroup,
                                       emptyCarrier));
            }
            ++neighbour;
          }
        }
      }
    }
  }
}

static bool included(const vector<Group *> &v, Group *p)
{
  for(unsigned int i = 0; i < v.size(); i++) {
    if(v[i] == p)
      return true;
  }
  return false;
}

enum TaintT { TAINT_NOTHING,
              TAINT_END_GROWN_TO, TAINT_END_GROWN, TAINT_END_CHANGED_TYPE,
              TAINT_CARRIER, TAINT_ENDS_SAME };
typedef enum TaintT Taint;

static Taint tainted(Group *ng, Group *eg,
                     const vector<Group *> &dg,
                     const SubGame &sg, Poi<SubGame> *untainted)
{
  assert(untainted);
  assert(eg);
  *untainted = 0;
  if(!ng) {
    assert(dg.size() == 0);
    // we don't have a new group to untaint with
    if(sg.has(eg)) {
      // let's return the most serious one, so it gets deleted ...
      return TAINT_ENDS_SAME;
    }
    return TAINT_NOTHING;
  } else {
    bool xTainted = (included(dg, sg.x()) || eg == sg.x());
    bool yTainted = (included(dg, sg.y()) || eg == sg.y());
    bool carrierTainted = sg.carrier().has(eg->fields()[0]);
    if(xTainted || yTainted || carrierTainted) {
      if(xTainted && yTainted) {
        return TAINT_ENDS_SAME;
      } else if(carrierTainted) {
        return TAINT_CARRIER;
      } else {
        Group *x = (xTainted ? ng : sg.x());
        Group *y = (yTainted ? ng : sg.y());
        Carrier c(sg.carrier());
        *untainted = Poi<SubGame>(new SubGame(x, y, c, sg.semi()));
        if((xTainted && sg.x()->mark() != x->mark()) ||
           (yTainted && sg.y()->mark() != y->mark())) {
          return TAINT_END_CHANGED_TYPE;
        } else {
          assert(!dg.empty());
          if((xTainted && sg.x() == dg.front()) ||
             (yTainted && sg.y() == dg.front())) {
            return TAINT_END_GROWN_TO;
          } else {
            return TAINT_END_GROWN;
          }
        }
      }
    } else {
      return TAINT_NOTHING;
    }
  }
}

void Connector::updateConns(Group *newGroup, Group *emptyGroup,
                             const vector<Group *> &unitedGroups)
{
  vector<Poi<SubGame> > toBeAdded;
  {
    ConnBatchMap::iterator cur = _connMap.begin();
    ConnBatchMap::iterator end = _connMap.end();
    ConnBatchMap::iterator next;
    ConnBatch::iterator setcur, setend, setnext;
    while(cur != end) {
      next = cur;
      ++next;
      ConnBatch &s = (*cur).second;
      setcur = s.begin();
      setend = s.end();
      while(setcur != setend) {
        setnext = setcur;
        ++setnext;
#if LOG_UPDATE_CONN
        cout << "Considering conn: " << **setcur << endl;
#endif
        Poi<SubGame> untainted;
        Taint taint = tainted(newGroup, emptyGroup, unitedGroups,
                              **setcur, &untainted);

        if(taint == TAINT_END_GROWN_TO) {
          assert(!untainted.null());
          if((**setcur).processed()) {
            (*untainted).setProcessed();
          }
#if LOG_UPDATE_CONN
          cout << "Instant update: " << *untainted << endl;
#endif
          removeFromConnFanMap(&**setcur);
          (**setcur).setProcessed();
          s.erase(setcur);
          addConn(untainted);
        } else if(taint == TAINT_END_GROWN ||
                  taint == TAINT_END_CHANGED_TYPE) {
          assert(!untainted.null());
#if LOG_UPDATE_CONN
          cout << "New: " << *untainted << endl;
#endif
          removeFromConnFanMap(&**setcur);
          (**setcur).setProcessed();
          s.erase(setcur);
          toBeAdded.push_back(untainted);
        } else if(taint == TAINT_CARRIER || taint == TAINT_ENDS_SAME) {
          assert(untainted.null());
#if LOG_UPDATE_CONN
          cout << "Delete" << endl;
#endif
          removeFromConnFanMap(&**setcur);
          (**setcur).setProcessed();
          s.erase(setcur);
        } else {
          assert(taint == TAINT_NOTHING);
        }
        setcur = setnext;
      }
      if(s.empty()) {
        _connMap.erase(cur);
      }
      cur = next;
    }
  }

  {
    for(int i = 0; (unsigned)i < toBeAdded.size(); i++) {
      tryToAddConn(toBeAdded[i]);
    }
  }

  if(_softMaxConn > 0) {
    ConnBatchMap::iterator cur = _connMap.begin();
    ConnBatchMap::iterator end = _connMap.end();
    ConnBatch::iterator setcur, setend;
    while(cur != end) {
      ConnBatch &s = (*cur).second;
      setcur = s.begin();
      setend = s.end();
      int n = 0;
      while(setcur != setend && n < _softMaxConn) {
        if((**setcur).waiting()) {
          enqueue(*setcur);
        }
        n++;
        setcur++;
      }
      cur++;
    }
  }
}

void Connector::updateSemis(Group *newGroup, Group *emptyGroup,
                             const vector<Group *> &unitedGroups)
{
  vector<Poi<SubGame> > toBeAdded;

  SemiBatchMap::iterator cur = _semiMap.begin();
  SemiBatchMap::iterator end = _semiMap.end();
  SemiBatchMap::iterator next;
  SemiBatch::iterator setcur;
  SemiBatch::iterator setend;
  SemiBatch::iterator setnext;
  while(cur != end) {
    next = cur;
    ++next;
    SemiBatch &s = (*cur).second;
    setcur = s.begin();
    setend = s.end();
    while(setcur != setend) {
      setnext = setcur;
      ++setnext;
#if LOG_UPDATE_SEMI
      cout << "Considering semi: " << **setcur << endl;
#endif
      Poi<SubGame> untainted;
      Taint taint = tainted(newGroup, emptyGroup, unitedGroups,
                            **setcur, &untainted);

      if(taint == TAINT_END_GROWN_TO ||
         (taint == TAINT_END_CHANGED_TYPE && unitedGroups.empty())) {
        assert(!untainted.null());
        if((**setcur).processed()) {
          (*untainted).setProcessed();
        }
#if LOG_UPDATE_SEMI
        cout << "Instant update: " << *untainted << endl;
#endif
        (**setcur).setProcessed();
        s.erase(setcur);
        addSemi(untainted);
      } else if(taint == TAINT_END_GROWN || taint == TAINT_END_CHANGED_TYPE) {
        assert(!untainted.null());
#if LOG_UPDATE_SEMI
        cout << "Deferred recalc: " << *untainted << endl;
#endif
        (**setcur).setProcessed();
        s.erase(setcur);
        toBeAdded.push_back(untainted);
      } else if(taint == TAINT_CARRIER || taint == TAINT_ENDS_SAME) {
        assert(untainted.null());
#if LOG_UPDATE_SEMI
        cout << "Delete" << endl;
#endif
        (**setcur).setProcessed();
        s.erase(setcur);
      } else {
        assert(taint == TAINT_NOTHING);
      }
      setcur = setnext;
    }
    if(s.empty()) {
      _semiMap.erase(cur);
    }
    cur = next;
  }

  {
    for(int i = 0; (unsigned)i < toBeAdded.size(); i++) {
      tryToAddSemi(toBeAdded[i]);
    }
  }

  if(_softMaxSemi > 0) {
    cur = _semiMap.begin();
    end = _semiMap.end();
    while(cur != end) {
      SemiBatch &s = (*cur).second;
      setcur = s.begin();
      setend = s.end();
      int n = 0;
      while(setcur != setend && n < _softMaxSemi) {
        if((**setcur).waiting()) {
          enqueue(*setcur);
        }
        n++;
        setcur++;
      }
      cur++;
    }
  }
}

class GroupPAreaComparator
{
public:
  bool operator ()(const Group *g0, const Group *g1)
  {
    return g0->area() > g1->area();
  }
};

void Connector::move(const HexMove &move, bool doReinitOnEdge)
{
  moveWithoutCalc(move, doReinitOnEdge);
  calc();
}

void Connector::moveWithoutCalc(const HexMove &move, bool doReinitOnEdge)
{
  if(move.isSwap()) {
    HexBoard b(_groups.board().transvert());
    initWithoutCalc(b, _groups.mark());
  } else {
    pair<Poi<Group>, vector<Poi<Group> > > g =
      _groups.move(move.field(), move.mark());
    assert((_groups.mark() == move.mark()) == (g.first.null() == 0));
    Group *newGroup = (g.first.null() ? 0 : (&*g.first));
    Group *emptyGroup = &*g.second[0];
    vector<Group *> unitedGroups;
    bool touchesEdge = false;
    for(unsigned i = 1; i < g.second.size(); i++) {
      unitedGroups.push_back(&*g.second[i]);
      if(unitedGroups.back()->edge())
        touchesEdge = true;
    }
    if(_useEdge || !touchesEdge || (touchesEdge && !doReinitOnEdge)) {
      sort(unitedGroups.begin(), unitedGroups.end(), GroupPAreaComparator());
      updateConns(newGroup, emptyGroup, unitedGroups);
      updateSemis(newGroup, emptyGroup, unitedGroups);
      _potentialWinner = _winner = _groups.board().winner();
      ConnBatchMap::const_iterator wPaths = winningConnBatch();
      if(wPaths != _connMap.end()) {
        assert(!(*wPaths).second.empty());
        _potentialWinner = _groups.mark();
      }
    } else {
      HexBoard b(_groups.board());
      initWithoutCalc(b, _groups.mark());
    }
  }
}

void Connector::setPotentialWinner(const SubGame &conn)
{
  if(conn.x()->edge() && conn.y()->edge()) {
    // it cannot have the same edge at both ends
    // so it's a winning virtual connection
    _potentialWinner = _groups.mark();
    assert(_potentialWinner != HEX_MARK_EMPTY);
#if LOG_WIN
    cout << "Winning path: " << conn << endl;
#endif
  }
}

void Connector::calc()
{
#if LOG_CALC
  cout << "To process: " << _subgameQueue.size() << endl;
  for(unsigned i = 0; i < _subgameQueue.size(); i++) {
    if(!(*_subgameQueue[i]).processed()) {
      cout << *_subgameQueue[i] << endl;
    }
  }
#endif

  int nConn = 0, nSemi = 0, n = 0;
  while(!_stop &&
        !_subgameQueue.empty() &&
        _winner == HEX_MARK_EMPTY && _potentialWinner == HEX_MARK_EMPTY) {
#if LOG_CALC
    cout << "To process: " << _subgameQueue.size() << endl;
#endif
    const Poi<SubGame> g = _subgameQueue.front();
    _subgameQueue.erase(_subgameQueue.begin());
    if(!(*g).processed()) {
      if((*g).semi()) {
        processSemi(*g);
        nSemi++;
      } else {
        processConn(*g);
        nConn++;
      }
      (*g).setProcessed();
    }

    if((n % 200) == 0 && _task) {
      _task->doSlice();
    }

    n++;
  }

#if LOG_CALC
  cout << "Processed: " << n << endl;
  cout << "Processed conn: " << nConn << endl;
  cout << "Processed semi: " << nSemi << endl;
#endif
}

HexMark Connector::winner() const
{
  return _winner;
}

HexMark Connector::potentialWinner() const
{
  return _potentialWinner;
}

Connector::ConnBatchMap::const_iterator Connector::winningConnBatch() const
{
  HexField e0 = ((_groups.mark() == HEX_MARK_VERT) ?
                 HexBoard::TOP_EDGE : HexBoard::LEFT_EDGE);
  HexField e1 = ((_groups.mark() == HEX_MARK_VERT) ?
                 HexBoard::BOTTOM_EDGE : HexBoard::RIGHT_EDGE);
  Conn2Key wb(&*_groups[_groups(e0)], &*_groups[_groups(e1)]);
  return _connMap.find(wb);
}

Carrier Connector::winningCarrier() const
{
  assert(_winner == HEX_MARK_EMPTY);
  assert(_potentialWinner == _groups.mark());
  ConnBatchMap::const_iterator wPaths = winningConnBatch();
  assert(wPaths != _connMap.end());
  const ConnBatch &c = (*wPaths).second;
  assert(!c.empty());
  return (**c.begin()).carrier();
}

const Connector::ConnBatchMap &Connector::conns() const
{
  return _connMap;
}

const Connector::SemiBatchMap &Connector::semis() const
{
  return _semiMap;
}

const Grouping &Connector::grouping() const
{
  return _groups;
}

const HexBoard &Connector::board() const
{
  return _groups.board();
}
