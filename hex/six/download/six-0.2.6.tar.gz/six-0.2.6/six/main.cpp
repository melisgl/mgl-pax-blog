#include "ksix.h"

#include <kapp.h>
#include <dcopclient.h>
#include <kaboutdata.h>
#include <kcmdlineargs.h>
#include <klocale.h>

static const char *description = I18N_NOOP("Six is a Hex playing program.");

static const char *version = "v0.2.6";

static KCmdLineOptions options[] =
{
    { 0, 0, 0 }
};

int main(int argc, char **argv)
{
  KAboutData about("six", I18N_NOOP("Six"), version, description,
                   KAboutData::License_GPL, "(C) 2002 Gabor Melis",
                   0, 0, "mega@hotpop.com");
  about.addAuthor("Gabor Melis", 0, "mega@hotpop.com");
  KCmdLineArgs::init(argc, argv, &about);
  KCmdLineArgs::addCmdLineOptions(options);
  KApplication app;

  // register ourselves as a dcop client
  app.dcopClient()->registerAs(app.name(), false);

  // see if we are starting with session management
  if (app.isRestored()) {
    RESTORE(KSix);
  } else {
    // no session.. just start up normally
    KCmdLineArgs *args = KCmdLineArgs::parsedArgs();
    KSix *widget = new KSix;
    widget->show();
    args->clear();
  }

  return app.exec();
}
