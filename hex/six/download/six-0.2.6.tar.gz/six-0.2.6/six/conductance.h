// Yo Emacs, this -*- C++ -*-
#ifndef CONDUCTANCE_H
#define CONDUCTANCE_H

#include "connector.h"
#include "vec.h"
#include "mat.h"

/**
 * This class encapsulates the result of conductance measurement for a
 * circuit defined by a @ref Connector.
 *
 * The circuit is defined the following way:
 * A wire is added between two groups if and only if there is a virtual
 * connection between them. Between two groups there is at most one wire.
 *
 * Resistance of a wire is high if it connects two empty groups.
 * Resistance is medium if it connects an empty and a non-empty group.
 * Resistance is low if it connects two non-empty groups.
 * Well, at least roughly. See the code for the details.
 *
 * For the vertical player the group of TOP_EDGE is the ground
 * and 1 unit of current is applied to the group of BOTTOM_EDGE.
 *
 * Resistance is calculated according to the Kirchhoff rules using
 * Nodal Analysis (see @ref http://www.ecs.soton.ac.uk/~mz/CctSim/).
 *
 * Energy level of a group is the sum of unsigned current that
 * flows through between it and each of its neighbours.
 */
class Conductance
{
public:
  /**
   * Calculates conductance for the circuit defined by groups
   * and virtual connections in connector <code>c</code>.
   *
   * FIXME:
   * Somewhat ugly to do all these calculations in the constructor.
   * But it's faster than copying it around.
   */
  Conductance(const Connector &c);

  /**
   * The resistance between the edges of connector's mark of interest.
   */
  double resistance() const;

  /**
   * Returns the energy level of the empty group <code>gi</code>.
   */
  double energy(Grouping::GroupIndex gi) const;
private:
  static double connResistance(const Connector::ConnBatch &);
  double _resistance;
  Vec<double> _energy;
};

#endif
