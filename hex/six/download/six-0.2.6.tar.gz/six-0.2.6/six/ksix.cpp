#include "ksix.h"

#include "sixplayer.h"
#include "asyncplayer.h"

#include <cassert>
#include <kprinter.h>
#include <qpainter.h>
#include <qpaintdevicemetrics.h>

#include <qbuttongroup.h>
#include <qhbox.h>

#include <kglobal.h>
#include <klocale.h>
#include <kiconloader.h>
#include <kmenubar.h>
#include <kkeydialog.h>
#include <kaccel.h>
#include <kio/netaccess.h>
#include <kfiledialog.h>
#include <kconfig.h>
#include <kurl.h>
#include <kurlrequesterdlg.h>
#include <kcursor.h>

#include <kedittoolbar.h>

#include <kstdaccel.h>
#include <kaction.h>
#include <kstdaction.h>
#include <kmessagebox.h>

enum { STATUSBAR_MSG = 0 };

QString KSix::secToQString(int sec)
{
  int h = sec / 3600;
  int m = (sec % 3600) / 60;
  int s = (sec % 60);
  QString r;
  r.sprintf("%d:%.2d:%.2d", h, m, s);
  return r;
}

QString KSix::playerToString(PlayerType p)
{
  switch(p) {
  case PLAYER_HUMAN:
    return "human";
  case PLAYER_BEGINNER:
    return "beginner";
  case PLAYER_INTERMEDIATE:
    return "intermediate";
  case PLAYER_ADVANCED:
    return "advanced";
  case PLAYER_EXPERT:
    return "expert";
  default:
    assert(0);
  }
}

KSix::PlayerType KSix::stringToPlayer(const QString &s)
{
  if(s == "human") {
    return PLAYER_HUMAN;
  }
  if(s == "beginner") {
    return PLAYER_BEGINNER;
  }
  if(s == "intermediate") {
    return PLAYER_INTERMEDIATE;
  }
  if(s == "advanced") {
    return PLAYER_ADVANCED;
  }
  if(s == "expert") {
    return PLAYER_EXPERT;
  }
  assert(0);
}

KSix::KSix()
    : KMainWindow(0, "six"),
      _hexWidget(new KHexWidget(this)),
      _printer(0)
{
  _blackPlayer = PLAYER_NONE;
  _whitePlayer = PLAYER_NONE;
  _thinking = false;
  _stopGame = false;
  _updatePlayer = false;

  // tell the KMainWindow that this is indeed the main widget
  setCentralWidget(_hexWidget);

  // then, setup our actions
  setupActions();

  // and a status bar
  statusBar()->show();
  statusBar()->insertItem("", STATUSBAR_MSG, 1);
  statusBar()->setItemAlignment(STATUSBAR_MSG, AlignLeft | AlignVCenter);
  connect(statusBar(), SIGNAL(released(int)),
          this, SLOT(handleStatusBarClick(int)));

  // add a frame containig black's clock
  {
    QHBox *hbox= new QHBox(statusBar(), 0);
    _blackClockMark = new QLabel(hbox, 0);
    _blackClockMark->setPixmap(BarIcon("blackmark"));
    _blackClockLabel = new QLabel(hbox);
    statusBar()->addWidget(hbox, 0, 1);
  }
  // add a frame containig white's clock
  {
    QHBox *hbox= new QHBox(statusBar(), 0);
    _whiteClockMark = new QLabel(hbox, 0);
    _whiteClockMark->setPixmap(BarIcon("whitemark"));
    _whiteClockLabel = new QLabel(hbox);
    statusBar()->addWidget(hbox, 0, 1);
  }

  connect(_hexWidget, SIGNAL(signalClickLeft(HexField)),
          this, SLOT(clickLeft(HexField)));

  readOptions();
}

KSix::~KSix()
{
}

void KSix::setupActions()
{
    _gameNewAction =
      new KAction(i18n("&New Game"), QIconSet(BarIcon("filenew")),
                  KStdAccel::key(KStdAccel::New),
                  this, SLOT(gameNew()),
                  actionCollection(), "fileNewGame");

//     KStdAction::open(this, SLOT(fileOpen()), actionCollection());
//     KStdAction::save(this, SLOT(fileSave()), actionCollection());
//     KStdAction::saveAs(this, SLOT(fileSaveAs()), actionCollection());

    new KAction(i18n("&Print Position"), QIconSet(BarIcon("fileprint")),
                KStdAccel::key(KStdAccel::Print),
                this, SLOT(filePrint()),
                actionCollection(), "filePrintPosition");

    KStdAction::quit(this, SLOT(quit()), actionCollection());

    // game
    _gameBackAction =
      new KAction(i18n("&Back"), QIconSet(BarIcon("back")),
                  KStdAccel::key(KStdAccel::Back),
                  this, SLOT(gameBack()),
                  actionCollection(), "gameBack");

    _gameForwardAction =
      new KAction(i18n("&Forward"), QIconSet(BarIcon("forward")),
                  KStdAccel::key(KStdAccel::Forward),
                  this, SLOT(gameForward()),
                  actionCollection(), "gameForward");

    _gameSuspendAction =
      new KAction(i18n("&Pause"), BarIcon("pause"),
                  Key_P, this, SLOT(gameSuspend()),
                  actionCollection(), "gameSuspend");

    _gameResumeAction =
      new KAction(i18n("&Continue"), BarIcon("play"),
                  Key_C, this, SLOT(gameResume()),
                  actionCollection(), "gameResume");

    _gameSwapAction =
      new KAction(i18n("&Swap"), BarIcon("swap"),
                  0, this, SLOT(gameSwap()),
                  actionCollection(), "gameSwap");

    // bars
    _toolbarAction = KStdAction::showToolbar(this, SLOT(showToolbar()),
                                             actionCollection());
    _statusbarAction = KStdAction::showStatusbar(this, SLOT(showStatusbar()),
                                                 actionCollection());

    // swap allowed
    _toggleSwapAction =
      new KToggleAction(i18n("Swa&p Allowed"), 0, this, SLOT(toggleSwap()),
                        actionCollection(), "swapAllowed");

    // board size
    {
      QStringList itemList;
      _boardSizeAction = new KSelectAction(i18n("Board Si&ze"), 0,
                                             actionCollection(), "boardSize");
      itemList.append(i18n("&4"));
      itemList.append(i18n("&5"));
      itemList.append(i18n("&6"));
      itemList.append(i18n("&7"));
      itemList.append(i18n("&8"));
      itemList.append(i18n("&9"));
      itemList.append(i18n("&10"));
      itemList.append(i18n("&11"));
      _boardSizeAction->setItems(itemList);
      connect(_boardSizeAction, SIGNAL(activated(int)),
              this, SLOT(setBoardSizeByMenuItem(int)));
    }

    // numbering
    _toggleNumberingAction = 
      new KToggleAction(i18n("Move &Numbering"), 0,
                        this, SLOT(toggleNumbering()),
                        actionCollection(), "moveNumbering");

    // show thinking
    _showThinkingAction = 
      new KToggleAction(i18n("Show Th&inking"), 0,
                        this, SLOT(toggleShowThinking()),
                        actionCollection(), "showThinking");

    // display mode
    {
      QStringList itemList;
      _displayModeAction =
        new KSelectAction(i18n("&Display Mode"), 0,
                          actionCollection(), "displayMode");
      itemList.append(i18n("&Diagonal"));
      itemList.append(i18n("&Flat"));
      _displayModeAction->setItems(itemList);
      connect(_displayModeAction, SIGNAL(activated(int)),
              this, SLOT(setDisplayModeByMenuItem(int)));
    }

    // black player
    {
      QStringList itemList;
      _blackPlayerAction =
        new KSelectAction(i18n("&Black Player"), BarIcon("blackmark"), 0,
                          actionCollection(), "blackPlayer");
      itemList.append(i18n("&Human"));
      itemList.append(i18n("&Beginner"));
      itemList.append(i18n("&Intermediate"));
      itemList.append(i18n("&Advanced"));
      itemList.append(i18n("&Expert"));
      _blackPlayerAction->setItems(itemList);
      connect(_blackPlayerAction, SIGNAL(activated(int)),
              this, SLOT(setBlackPlayerByMenuItem(int)));
    }

    // white player
    {
      QStringList itemList;
      _whitePlayerAction =
        new KSelectAction(i18n("&White Player"), BarIcon("whitemark"), 0,
                          actionCollection(), "whitePlayer");
      itemList.append(i18n("&Human"));
      itemList.append(i18n("&Beginner"));
      itemList.append(i18n("&Intermediate"));
      itemList.append(i18n("&Advanced"));
      itemList.append(i18n("&Expert"));
      _whitePlayerAction->setItems(itemList);
      connect(_whitePlayerAction, SIGNAL(activated(int)),
              this, SLOT(setWhitePlayerByMenuItem(int)));
    }

    // configure
    KStdAction::keyBindings(this, SLOT(configureKeys()), actionCollection());
    KStdAction::configureToolbars(this, SLOT(configureToolbars()),
                                  actionCollection());
    KStdAction::saveOptions(this, SLOT(saveOptions()), actionCollection());

    createGUI();
}

void KSix::closeEvent(QCloseEvent *)
{
  quit();
}

void KSix::saveProperties(KConfig *config)
{
  // the 'config' object points to the session managed
  // config file.  anything you write here will be available
  // later when this app is restored
  config->setGroup("General");
  config->writeEntry("version", "0.1");
  config->setGroup("Appearance");
  config->writeEntry("geometry", size());
  config->writeEntry("showToolBar", _toolbarAction->isChecked());
  config->writeEntry("showStatusBar", _statusbarAction->isChecked());
  config->setGroup("Game Options");
  config->writeEntry("swapAllowed", _toggleSwapAction->isChecked());
  config->writeEntry("boardSize", (*_match).game().board().xs());
  config->writeEntry("blackPlayer", playerToString(_blackPlayer));
  config->writeEntry("whitePlayer", playerToString(_whitePlayer));
  config->setGroup("Display Options");
  config->writeEntry("moveNumbering", _toggleNumberingAction->isChecked());
  config->writeEntry("showThinking", _showThinkingAction->isChecked());
  if(_displayModeAction->currentItem() == 0) {
    config->writeEntry("displayMode", "diagonal");
  } else {
    config->writeEntry("displayMode", "flat");
  }
}

void KSix::readProperties(KConfig *config)
{
  // the 'config' object points to the session managed
  // config file.  this function is automatically called whenever
  // the app is being restored.  read in here whatever you wrote
  // in 'saveProperties'
  config->setGroup("Appearance");
  QSize defSize(600, 500);
  QSize size = config->readSizeEntry("geometry", &defSize);
  bool stb = config->readBoolEntry("showToolBar", true);
  bool ssb = config->readBoolEntry("showStatusBar", true);
  config->setGroup("Game Options");
  bool sa = config->readBoolEntry("swapAllowed", true);
  int bs = config->readNumEntry("boardSize", 11);
  PlayerType bp = stringToPlayer(config->readEntry("blackPlayer", "human"));
  PlayerType wp = stringToPlayer(config->readEntry("whitePlayer", "beginner"));
  config->setGroup("Display Options");
  bool mn = config->readBoolEntry("moveNumbering", true);
  bool st = config->readBoolEntry("showThinking", false);
  QString dm = config->readEntry("displayMode", "diagonal");

  resize(size);

  if(_toolbarAction->isChecked() != stb) {
    _toolbarAction->activate();
  }
  
  if(_statusbarAction->isChecked() != ssb) {
    _statusbarAction->activate();
  }

  _blackPlayerAction->setCurrentItem(bp);
  setBlackPlayerByMenuItem(bp);
  _whitePlayerAction->setCurrentItem(wp);
  setWhitePlayerByMenuItem(wp);

  assert(4 <= bs && bs <= 11);
  _boardSizeAction->setCurrentItem(bs - 4);
  _boardSize = bs;

  if(_toggleSwapAction->isChecked() != sa) {
    _toggleSwapAction->activate();
  }

  if(_toggleNumberingAction->isChecked() != mn) {
    _toggleNumberingAction->activate();
  }

  if(_showThinkingAction->isChecked() != st) {
    _showThinkingAction->activate();
  }

  if(dm == "diagonal") {
    _displayModeAction->setCurrentItem(0);
    setDisplayModeByMenuItem(0);
  } else {
    _displayModeAction->setCurrentItem(1);
    setDisplayModeByMenuItem(1);
  }
}

void KSix::saveOptions()
{
  KConfig *config = KGlobal::config();
  saveProperties(config);
  config->sync();
}

void KSix::readOptions()
{
  KConfig *config = KGlobal::config();
  readProperties(config);
}

void KSix::filePrint()
{
  // this slot is called whenever the File->Print menu is selected,
  // the Print shortcut is pressed (usually CTRL+P) or the Print toolbar
  // button is clicked
  if(!_printer) 
    _printer = new KPrinter;
  if(_printer->setup(this)) {
    QPainter p;
    p.begin(_printer);

    // we let our view do the actual printing
    QPaintDeviceMetrics metrics(_printer);
    _hexWidget->print(&p, metrics.width(), metrics.height());

    // and send the result to the printer
    p.end();
  }
}

void KSix::quit()
{
  setMatch();
  kapp->quit();
}

void KSix::showToolbar()
{
  // this is all very cut and paste code for showing/hiding the
  // toolbar
  if(_toolbarAction->isChecked())
    toolBar()->show();
  else
    toolBar()->hide();
}

void KSix::showStatusbar()
{
  // this is all very cut and paste code for showing/hiding the
  // statusbar
  if(_statusbarAction->isChecked())
    statusBar()->show();
  else
    statusBar()->hide();
}

void KSix::configureKeys()
{
  KKeyDialog::configureKeys(actionCollection(), "sixui.rc");
}

void KSix::configureToolbars()
{
  // use the standard toolbar editor
  KEditToolbar dlg(actionCollection());
  if(dlg.exec()) {
    // recreate our GUI
    createGUI();
  } 
}

void KSix::updateBoard()
{
  if(!_match.null()) {
    _hexWidget->setGame((*_match).game());
    if((*_match).status() != HexMatch::MATCH_OFF)
      flash();
  }
}

void KSix::updateActions()
{
  if(!_match.null()) {
    _gameBackAction->setEnabled((*_match).canBack());
    _gameForwardAction->setEnabled((*_match).canForward());
    _gameSuspendAction->setEnabled((*_match).status() == HexMatch::MATCH_ON);
    _gameResumeAction->setEnabled((*_match).status() == HexMatch::MATCH_OFF);
    bool e = (*_match).game().board().isEmpty() && !isThinking();
    _toggleSwapAction->setEnabled(e);
    _boardSizeAction->setEnabled(e);
    bool s = (*_match).game().isValidMove(HexMove()) &&
      (*_match).status() != HexMatch::MATCH_FINISHED &&
      (((*_match).game().next() == HEX_MARK_VERT &&
        _blackPlayer == PLAYER_HUMAN) ||
       ((*_match).game().next() == HEX_MARK_HORI &&
        _whitePlayer == PLAYER_HUMAN));
    _gameSwapAction->setEnabled(s);
  } else {
    _gameBackAction->setEnabled(0);
    _gameForwardAction->setEnabled(0);
    _gameSuspendAction->setEnabled(0);
    _gameResumeAction->setEnabled(0);
    _gameSwapAction->setEnabled(0);
  }
}

void KSix::updateClock()
{
  if(!_match.null()) {
    _blackClockLabel->
      setText(secToQString((*_match).vertClockTotal().second / 1000));
    _whiteClockLabel->
      setText(secToQString((*_match).horiClockTotal().second / 1000));
    if((*_match).status() != HexMatch::MATCH_ON) {
      _blackClockMark->setEnabled(0);
      _whiteClockMark->setEnabled(0);
    } else if((*_match).game().next() == HEX_MARK_VERT) {
      _blackClockMark->setEnabled(1);
      _whiteClockMark->setEnabled(0);
    } else {
      _blackClockMark->setEnabled(0);
      _whiteClockMark->setEnabled(1);
    }
  } else {
    _blackClockLabel->setText(secToQString(0));
    _whiteClockLabel->setText(secToQString(0));
    _blackClockMark->setEnabled(0);
    _whiteClockMark->setEnabled(0);
  }
}

void KSix::updateMessage()
{
  if(!_match.null()) {
    QString statusMessage;
    if((*_match).status() == HexMatch::MATCH_FINISHED) {
      if((*_match).game().board().winner() == HEX_MARK_VERT) {
        statusMessage = i18n("Black has won.");
      } else {
        statusMessage = i18n("White has won.");
      }
    } else if((*_match).status() == HexMatch::MATCH_OFF) {
      statusMessage = i18n("Game is paused.");
    } else {
      if((*_match).game().next() == HEX_MARK_VERT) {
        statusMessage = i18n("Black's turn.");
      } else {
        statusMessage = i18n("White's turn.");
      }
    }

    const vector<HexMove> &moves = (*_match).game().moves();
    QString m0(i18n("--"));
    if(!moves.empty()) {
      const HexMove &m = moves.back();
      if(m.isSwap()) {
        m0 = i18n("Swap");
      } else {
        int xc, yc;
        (*_match).game().board().field2Coords(m.field(), &xc, &yc);
        QString x = QString(QChar('A' + xc));
        QString y = QString::number(yc + 1);
        m0 = x + y;
      }
    }
    QString m1(i18n("--"));
    if(moves.size() > 1) {
      const HexMove &m = moves[moves.size() - 2];
      if(m.isSwap()) {
        m1 = i18n("Swap");
      } else {
        int xc, yc;
        (*_match).game().board().field2Coords(m.field(), &xc, &yc);
        QString x = QString(QChar('A' + xc));
        QString y = QString::number(yc + 1);
        m1 = x + y;
      }
    }

    QString s;
    if(!moves.empty()) {
      if(((moves.size() % 2) && (*_match).game().first() == HEX_MARK_VERT) ||
         (!(moves.size() % 2) && (*_match).game().first() == HEX_MARK_HORI)) {
        s = QString(i18n("%1. %2 --")).arg((moves.size() + 1) / 2).arg(m0);
      } else {
        s = QString(i18n("%1. %2 %3")).arg((moves.size() + 1) / 2).
          arg(m1).arg(m0);
      }
    }

    QString message(i18n("%1   %2"));
    statusBar()->changeItem(message.arg(s).arg(statusMessage),
                            STATUSBAR_MSG);
  }
}

void KSix::updateThinking()
{
  if(_showThinkingAction->isChecked() && isThinking() &&
     !_stopGame && !_updatePlayer) {
    HexMove newCandidateMove;
    if((*_match).status() == HexMatch::MATCH_OFF) {
      _hexWidget->stopFlash();
    } else {
      if(onTurn() == HEX_MARK_VERT)
        newCandidateMove = ((SixPlayer *)&*_black)->candidateMove();
      else
        newCandidateMove = ((SixPlayer *)&*_white)->candidateMove();
      if(!_hexWidget->isFlashing() || _candidateMove != newCandidateMove) {
        _candidateMove = newCandidateMove;
        vector<int> f;
        if(!_candidateMove.isSwap()) {
          f.push_back(_candidateMove.field() - HexBoard::FIRST_NORMAL_FIELD);
          _hexWidget->flashHexagons(f, 800, 1000000);
        }
      }
    }
  }
}

void KSix::turn()
{
  assert(!_stopGame || isThinking());
  if(!_stopGame && !isThinking()) {
    while(!_match.null() && (*_match).status() == HexMatch::MATCH_ON &&
          !isThinking() && !_stopGame &&
          ((onTurn() == HEX_MARK_VERT && _blackPlayer != PLAYER_HUMAN) ||
           (onTurn() == HEX_MARK_HORI && _whitePlayer != PLAYER_HUMAN))) {
      thinking(true);
      _candidateMove = HexMove();
      (*_match).doSome();
      thinking(false);
      _candidateMove = HexMove();
      if(_updatePlayer) {
        _oldBlack = 0;
        _oldWhite = 0;
        _updatePlayer = false;
        _hexWidget->stopFlash();
      }
    }
    _oldMatch = 0;
    if(_stopGame) {
      _stopGame = false;
      _hexWidget->stopFlash();
    }
    updateActions();
    updateMessage();
    updateClock();
  }
}


//

void KSix::gameNew()
{
  bool e = (*_match).game().board().isEmpty() && !isThinking();
  if(e || KMessageBox::questionYesNo(this, i18n("Start a new game?")) ==
     KMessageBox::Yes) {
    setMatch();
  }
}

void KSix::gameBack()
{
  if(!_match.null() && (*_match).canBack()) {
    if(!_stopGame && !_updatePlayer) {
      if(isThinking()) {
        if(_blackPlayer != PLAYER_HUMAN) {
          ((SixPlayer *)&*_black)->cancelMove();
        }
        if(_whitePlayer != PLAYER_HUMAN) {
          ((SixPlayer *)&*_white)->cancelMove();
        }
        _stopGame = true;
      }
      (*_match).back();
    }
  }
}

void KSix::gameForward()
{
  if(!_match.null() && (*_match).canForward()) {
    if(!_stopGame && !_updatePlayer) {
      if(isThinking()) {
        if(_blackPlayer != PLAYER_HUMAN) {
          ((SixPlayer *)&*_black)->cancelMove();
        }
        if(_whitePlayer != PLAYER_HUMAN) {
          ((SixPlayer *)&*_white)->cancelMove();
        }
        _stopGame = true;
      }
      (*_match).forward();
    }
  }
}

void KSix::gameSuspend()
{
  if(!_match.null() && (*_match).status() == HexMatch::MATCH_ON) {
    if(!_stopGame) {
      (*_match).off();
    }
  }
}

void KSix::gameResume()
{
  if(!_match.null() && (*_match).status() == HexMatch::MATCH_OFF) {
    if(!_stopGame) {
      (*_match).on();
      turn();
    }
  }
}

void KSix::gameSwap()
{
  if(!_match.null()) {
    HexMove move;
    const HexGame &g = (*_match).game();
    if(g.next() == HEX_MARK_VERT && _blackPlayer == PLAYER_HUMAN) {
      ((AsyncPlayer *)(&*_black))->play(move);
      (*_match).doSome();
      turn();
    } else if(g.next() == HEX_MARK_HORI && _whitePlayer == PLAYER_HUMAN) {
      ((AsyncPlayer *)(&*_white))->play(move);
      (*_match).doSome();
      turn();
    }
  }
}

void KSix::setBoardSize(int s)
{
  _boardSize = s;
  setMatch();
}

void KSix::setBoardSizeByMenuItem(int item)
{
  setBoardSize(item + 4);
}

void KSix::toggleSwap()
{
  _swapAllowed = _toggleSwapAction->isChecked();
  setMatch();
}

void KSix::toggleNumbering()
{
  if(_toggleNumberingAction->isChecked()) {
    _hexWidget->setNumbering(true);
  } else {
    _hexWidget->setNumbering(false);
  }
}

void KSix::toggleShowThinking()
{
  updateThinking();
}

void KSix::setDisplayModeByMenuItem(int i)
{
  if(i == 0)
    _hexWidget->setDisplayMode(KHexWidget::DISPLAY_DIAGONAL);
  else
    _hexWidget->setDisplayMode(KHexWidget::DISPLAY_FLAT);
}

void KSix::clickLeft(HexField f)
{
  if(!_match.null()) {
    if((*_match).status() != HexMatch::MATCH_FINISHED) {
      const HexGame &g = (*_match).game();
      HexMove move(g.next(), f);
      if(g.next() == HEX_MARK_VERT && _blackPlayer == PLAYER_HUMAN) {
        ((AsyncPlayer *)(&*_black))->play(move);
        (*_match).doSome();
        turn();
      } else if(g.next() == HEX_MARK_HORI && _whitePlayer == PLAYER_HUMAN) {
        ((AsyncPlayer *)(&*_white))->play(move);
        (*_match).doSome();
        turn();
      }
    }
    // silently ignore the click
  }
}

void KSix::handleStatusBarClick(int item)
{
  if(item == STATUSBAR_MSG) {
    flash();
  }
}

HexPlayer *KSix::createPlayer(PlayerType p)
{
  switch(p) {
  case PLAYER_HUMAN:
    return new AsyncPlayer();
  case PLAYER_BEGINNER:
    return new SixPlayer(SixPlayer::BEGINNER, this);
  case PLAYER_INTERMEDIATE:
    return new SixPlayer(SixPlayer::INTERMEDIATE, this);
  case PLAYER_ADVANCED:
    return new SixPlayer(SixPlayer::ADVANCED, this);
  case PLAYER_EXPERT:
    return new SixPlayer(SixPlayer::EXPERT, this);
  default:
    assert(0);
  }
}

void KSix::setBlack(PlayerType p, bool forceUpdate)
{
  if(!_stopGame && !_updatePlayer) {
    if(_blackPlayer != p || forceUpdate) {
      if(!_black.null()) {
        if(_blackPlayer != PLAYER_HUMAN && onTurn() == HEX_MARK_VERT
           && isThinking()) {
          _updatePlayer = true;
          _oldBlack = _black;
          ((SixPlayer *)&*_black)->cancelMove();
        }
      }
      _blackPlayer = p;
      _black = createPlayer(p);
      if(!_match.null()) {
        (*_match).setVerticalPlayer(_black);
      }
    }
  }
}

void KSix::setBlackPlayerByMenuItem(int i)
{
  setBlack((PlayerType)i);
  turn();
}

void KSix::setWhite(PlayerType p, bool forceUpdate)
{
  if(!_stopGame && !_updatePlayer) {
    if(_whitePlayer != p || forceUpdate) {
      if(!_white.null()) {
        if(_whitePlayer != PLAYER_HUMAN && onTurn() == HEX_MARK_HORI
           && isThinking()) {
          _updatePlayer = true;
          _oldWhite = _white;
          ((SixPlayer *)&*_white)->cancelMove();
        }
      }
      _whitePlayer = p;
      _white = createPlayer(p);
      if(!_match.null()) {
        (*_match).setHorizontalPlayer(_white);
      }
    }
  }
}

void KSix::setWhitePlayerByMenuItem(int i)
{
  setWhite((PlayerType)i);
  turn();
}

//
//
//

void KSix::setMatch()
{
  HexGame g(HexBoard(_boardSize, _boardSize), HEX_MARK_VERT, _swapAllowed);
  if(!_stopGame && !_updatePlayer) {
    if(isThinking()) {
      // We're not interested in this old match anymore,
      // but it must be kept alive until control returns from it.
      disconnect(&*_match, 0, 0, 0);
      _oldMatch = _match;
      // the match keeps its players alive, but we must create new ones
      setBlack(_blackPlayer, true);
      setWhite(_whitePlayer, true);
      _stopGame = true;
    }
    _match = new HexMatch(g, _black, _white);
    updateBoard();
    updateActions();
    updateClock();
    updateMessage();
    connect(&*_match, SIGNAL(signalPlayerChange()),
            this, SLOT(updateMessage()));
    connect(&*_match, SIGNAL(signalPlayerChange()),
            this, SLOT(updateThinking()));

    connect(&*_match, SIGNAL(signalPositionChange()),
            this, SLOT(updateBoard()));
    connect(&*_match, SIGNAL(signalPositionChange()),
            this, SLOT(updateActions()));
    connect(&*_match, SIGNAL(signalPositionChange()),
            this, SLOT(updateMessage()));

    connect(&*_match, SIGNAL(signalStatusChange()),
            this, SLOT(updateActions()));
    connect(&*_match, SIGNAL(signalStatusChange()),
            this, SLOT(updateMessage()));
    connect(&*_match, SIGNAL(signalStatusChange()),
            this, SLOT(updateClock()));

    connect(&*_match, SIGNAL(signalClockChange()),
            this, SLOT(updateClock()));
  }
}

void KSix::flash()
{
  if((*_match).status() == HexMatch::MATCH_FINISHED) {
    pair<HexMark, vector<int> > w = (*_match).game().board().winningPath();
    assert(w.first != HEX_MARK_EMPTY);
    for(unsigned i = 0; i < w.second.size(); i++)
      w.second[i] -= HexBoard::FIRST_NORMAL_FIELD;
    _hexWidget->flashHexagons(w.second, 100, 3);
  } else {
    const vector<HexMove> &moves = (*_match).game().moves();
    if(!moves.empty()) {
      vector<HexField> fl;
      const HexMove &m = moves.back();
      const HexBoard &b = (*_match).game().board();
      if(!m.isSwap()) {
        fl.push_back(m.field() - HexBoard::FIRST_NORMAL_FIELD);
      } else {
        for(HexField f = HexBoard::FIRST_NORMAL_FIELD; f < b.size(); f++) {
          if(b.get(f) != HEX_MARK_EMPTY)
            fl.push_back(f - HexBoard::FIRST_NORMAL_FIELD);
        }
      }
      _hexWidget->flashHexagons(fl, 66, 1);
    }
  }
}

void KSix::thinking(bool on)
{
  if(_thinking != on) {
    _thinking = on;
    if(_thinking)
      _hexWidget->setCursor(KCursor::waitCursor());
    else
      _hexWidget->setCursor(KCursor::arrowCursor());
  }
}

bool KSix::isThinking()
{
  return _thinking;
}

HexMark KSix::onTurn()
{
  return (*_match).game().next();
}

void KSix::doSlice()
{
  bool first = true;
  static struct timespec t = { 0, 100000000L };
  updateThinking();
  do {
    if(!first) {
      _hexWidget->stopFlash();
      // the game is suspended, let's wait a 0.1s to reduce CPU load
      nanosleep(&t, 0);
    }
    kapp->processEvents();
    first = false;
  } while((*_match).status() == HexMatch::MATCH_OFF &&
          !_stopGame && !_updatePlayer);
}

#include "ksix.moc"
