#include "hexgame.h"
#include <cassert>

HexGame::HexGame(const HexBoard &b, HexMark first, bool swappable)
  : _initialBoard(b), _currentBoard(b)
{
  _swappable = swappable;
  _first = first;
  _next = first;
  assert(_first != HEX_MARK_EMPTY);
}

const HexBoard &HexGame::board() const
{
  return _currentBoard;
}

const HexBoard &HexGame::initialBoard() const
{
  return _initialBoard;
}

bool HexGame::swappable() const
{
  return _swappable;
}

HexMark HexGame::first() const
{
  return _first;
}

HexMark HexGame::next() const
{
  return _next;
}

bool HexGame::isValidMove(const HexMove &move) const
{
  return ((move.isSwap() && _swappable && _currentBoard.nMark() == 1) ||
          (!move.isSwap() &&
           move.mark() == _next &&
           _currentBoard.isNormalField(move.field()) &&
           _currentBoard.get(move.field()) == HEX_MARK_EMPTY));
}

void HexGame::play(const HexMove &move)
{
  assert(isValidMove(move));
  if(move.isSwap()) {
    _currentBoard = _currentBoard.transvert();
    _swappable = false;
  } else {
    _currentBoard.set(move.field(), move.mark());
  }
  _next = ((_next == HEX_MARK_VERT) ? HEX_MARK_HORI : HEX_MARK_VERT);
  _moves.push_back(move);
}

HexMove HexGame::unplay()
{
  assert(!_moves.empty());
  HexMove m = _moves.back();
  _moves.pop_back();
  if(m.isSwap()) {
    _currentBoard = _currentBoard.transvert();
    _swappable = true;
  } else {
    _currentBoard.set(m.field(), HEX_MARK_EMPTY);
  }
  _next = ((_next == HEX_MARK_VERT) ? HEX_MARK_HORI : HEX_MARK_VERT);
  return m;
}

const vector<HexMove> &HexGame::moves() const
{
  return _moves;
}

void HexGame::printMove(ostream &os, const HexMove &m) const
{
  if(m.isSwap()) {
    os << "SWAP";
  } else {
    os << m.mark();
    _initialBoard.printField(os, m.field());
  }
}

ostream &operator <<(ostream &os, const HexGame &g)
{
  os << "Starting position:\n" << g._initialBoard;
  os << "Moves: ";
  for(unsigned int i = 0; i < g._moves.size(); i++) {
    if((i % 2) == 0)
      os << " " << (i / 2 + 1) << ".";
    os << " ";
    g.printMove(os,  g._moves[i]);
  }
  os << "\nCurrent position:\n" << g._currentBoard;
  HexMark winner = g._currentBoard.winner();
  if(winner != HEX_MARK_EMPTY) {
    os << "Winner is " << winner << ".\n";
  }
  return os;
}
