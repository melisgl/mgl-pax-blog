#include "subgame.h"
#include "misc.h"

#include <algorithm>

SubGame::SubGame(Group *x, Group *y, const Carrier &c, bool semi)
  : _c(c)
{
  assert(x != y);
  assert(!c.has(x->fields()[0]));
  assert(!c.has(y->fields()[0]));
  _x = MIN(x, y);
  _y = MAX(x, y);
  _enqueued = false;
  _processed = false;
  _semi = semi;
}

SubGame::SubGame(const SubGame &g0, const SubGame &g1) : _c(g0._c)
{
  Group *common;
  Group *x, *y;
  bool c = g0.concatable(g1, &x, &y, &common);
  assert(c);
  _x = MIN(x, y);
  _y = MAX(x, y);
  _c.unite(g1._c);
  _enqueued = false;
  _processed = false;
  if(common->mark() == HEX_MARK_EMPTY) {
    _c.addField(common->fields()[0]);
    _semi = true;
  } else {
    _semi = false;
  }
}

bool SubGame::waiting() const
{
  return !_enqueued && !_processed;
}

bool SubGame::enqueued() const
{
  return _enqueued;
}

void SubGame::setEnqueued()
{
  assert(!_processed);
  _enqueued = true;
}

bool SubGame::processed() const
{
  return _processed;
}

void SubGame::setProcessed()
{
  _processed = true;
}

bool SubGame::semi() const
{
  return _semi;
}

bool SubGame::operator ==(const SubGame &g) const
{
  return _x == g._x && _y == g._y && _c == g._c;
}

bool SubGame::operator <(const SubGame &g) const
{
  return (_x < g._x ||
          (_x == g._x && _y < g._y) ||
          (_x == g._x && _y == g._y && _c < g._c));
}

bool SubGame::includes(const SubGame &g) const
{
  return _x == g._x && _y == g._y && _c.includes(g._c);
}

bool SubGame::has(const Group *g) const
{
  return _x == g || _y == g || _c.has(g->fields()[0]);
}

bool SubGame::concatable(const SubGame &g,
                         Group **x, Group **y, Group **middle) const
{
  if(_x == g._x && _y != g._y) {
    *middle = _x;
    *x = _y;
    *y = g._y;
  } else if(_x == g._y && _y != g._x) {
    *middle = _x;
    *x = _y;
    *y = g._x;
  } else if(_y == g._x && _x != g._y) {
    *middle = _y;
    *x = _x;
    *y = g._y;
  } else if(_y == g._y && _x != g._x) {
    *middle = _y;
    *x = _x;
    *y = g._x;
  } else {
    return false;
  }
  return true;
}

Group *SubGame::x() const
{
  return _x;
}

Group *SubGame::y() const
{
  return _y;
}

const Carrier &SubGame::carrier() const
{
  return _c;
}

ostream &operator <<(ostream &os, const SubGame &sg)
{
  if(sg._semi) {
    os << "S";
  }
  if(*min_element((*sg.x()).fields().begin(), (*sg.x()).fields().end()) <
     *min_element((*sg.y()).fields().begin(), (*sg.y()).fields().end())) {
    os << "(" << *sg.x() << "," << *sg.y() << "," << sg.carrier() << ")";
  } else {
    os << "(" << *sg.y() << "," << *sg.x() << "," << sg.carrier() << ")";
  }
  if(sg.processed()) {
    os << "*";
  }
  if(sg.enqueued()) {
    os << "|";
  }
  return os;
}
