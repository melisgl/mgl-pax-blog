#include "conductance.h"
#include "lssolve.h"

#include <cassert>
#include <cmath>

Conductance::Conductance(const Connector &c)
{
  const Grouping &g = c.grouping();
  // ground is the first group, so we have one less groups
  const int n = g.size() - 1;
  Mat<double> G(n, n);
  Vec<double> groundG(n);
  Vec<double> I(n);
  G = 0.;
  groundG = 0.;
  I = 0.;

  Grouping::GroupIndex ground, phase;
  int phaseIndex;
  if(g.mark() == HEX_MARK_VERT) {
    ground = g(HexBoard::TOP_EDGE);
    phase = phaseIndex = g(HexBoard::BOTTOM_EDGE);
  } else {
    ground = g(HexBoard::LEFT_EDGE);
    phase = phaseIndex = g(HexBoard::RIGHT_EDGE);
  }
  if(phase > ground)
    phaseIndex--;
  I[phaseIndex] = 1;

  Grouping::GroupIndex k, j;
  int ki, ji;
  double conductance;
  Connector::ConnBatchMap::const_iterator cur = c.conns().begin();
  Connector::ConnBatchMap::const_iterator end = c.conns().end();
  while(cur != end) {
    conductance = 1. / connResistance((*cur).second);
    k = ki = g.groupIndex((*cur).first.start());
    j = ji = g.groupIndex((*cur).first.end());
    assert(k != j);
    if(ki > ground)
      ki--;
    if(ji > ground)
      ji--;
    // apply the element's stamp
    if(k != ground)
      G(ki, ki) += conductance;
    else
      groundG[ji] += conductance;
    if(j != ground)
      G(ji, ji) += conductance;
    else
      groundG[ki] += conductance;
    if(k != ground && j != ground) {
      G(ki, ji) -= conductance;
      G(ji, ki) -= conductance;
    }
    ++cur;
  }
  const Vec<double> &Y = lsSolve(G, I);
  _resistance = fabs(Y[phaseIndex]);
  assert(_resistance >= 0.);
  // Now, let the energy for group be the sum of current flowing
  // between the group and its neighbours.
  {
    _energy.setSize(n + 1);
    _energy = 0.;
    for(k = 0; k < n + 1; k++) {
      if((*g[k]).mark() == HEX_MARK_EMPTY) {
        assert(k != ground);
        ki = ((k > ground) ? (k - 1) : k);
        double sum = fabs(groundG[ki] * Y[ki]);
        for(ji = 0; ji < n; ji++) {
          if(ji != ki)
            sum += fabs(G(ki, ji) * (Y[ki] - Y[ji]));
        }
        _energy[k] = sum;
        assert(_energy[k] >= 0.);
      } else {
        _energy[k] = -1.;
      }
    }
  }
  assert(_resistance >= 0.);
}

double Conductance::resistance() const
{
  assert(_resistance >= 0.);
  return _resistance;
}

double Conductance::energy(Grouping::GroupIndex gi) const
{
  assert(gi >= 0 && gi < _energy.size());
  assert(_energy[gi] >= 0.);
  return _energy[gi];
}

// FIXME: more play tests are needed for resistance values
double Conductance::connResistance(const Connector::ConnBatch &cb)
{
  assert(!cb.empty());
  const SubGame &sg = **cb.begin();
  bool empty = sg.carrier().empty();
  if(sg.x()->mark() == HEX_MARK_EMPTY && sg.y()->mark() == HEX_MARK_EMPTY) {
    if(empty) {
      return 1.0;
    } else {
      return 2.0;
    }
  } else if(sg.x()->mark() == HEX_MARK_EMPTY ||
            sg.y()->mark() == HEX_MARK_EMPTY) {
    if(empty) {
      return 0.5;
    } else {
      return 1.0;
    }
  } else {
    assert(!empty);
    return 0.001;
  }
}
