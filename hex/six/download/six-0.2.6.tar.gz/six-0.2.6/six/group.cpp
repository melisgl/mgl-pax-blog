#include "group.h"

#include <algorithm>

//
// RMap
//

Grouping::RMap::RMap(int boardSize) : _v(boardSize)
{
  for(unsigned i = 0; i < _v.size(); i++)
    _v[i] = -1;
}

Grouping::GroupIndex &Grouping::RMap::operator [](HexField f)
{
  assert(0 <= f && f < (int)_v.size());
  return _v[f];
}

const Grouping::GroupIndex &Grouping::RMap::operator [](HexField f) const
{
  assert(0 <= f && f < (int)_v.size());
  return _v[f];
}

//
// Grouping
//

void Grouping::set(const HexBoard &b, HexMark mark)
{
  assert(mark != HEX_MARK_EMPTY);
  _board = b;
  _mark = mark;
  _groups.clear();
  _rmap = RMap(_board.size());
  for(HexField f = HexBoard::NOT_A_FIELD + 1; f < b.size(); f++) {
    if(_rmap[f] == -1 && b.get(f) == mark || b.get(f) == HEX_MARK_EMPTY) {
      _groups.push_back(new Group(_groups.size(), b, f, &_rmap));
    }
  }
}

pair<Poi<Group>, vector<Poi<Group> > > Grouping::move(HexField f, HexMark mark)
{
  assert(_board.isNormalField(f));
  assert(_mark != HEX_MARK_EMPTY);
  assert(_board.get(f) == HEX_MARK_EMPTY);
  _board.set(f, mark);
  pair<Poi<Group>, vector<Poi<Group> > > r;
  vector<int> deleted;
  // remove group at move
  int midx = (*this)(f);
  if(midx >= 0) {
    r.second.push_back((*this)[midx]);
    deleted.push_back(midx);
  }
  if(mark == _mark) {
    // neighbours of the same color should be deleted -> add to r.second
    HexBoard::Iterator neighbour = _board.neighbourBegin(f);
    while(neighbour != _board.neighbourEnd()) {
      int nidx = (*this)(*neighbour);
      if(nidx >= 0 && (*(*this)[nidx]).mark() == _mark) {
        const Poi<Group> &toDelete = (*this)[nidx];
        unsigned j;
        for(j = 0; j < r.second.size(); j++) {
          if(r.second[j] == toDelete)
            break;
        }
        if(j == r.second.size()) {
          r.second.push_back((*this)[nidx]);
          deleted.push_back(nidx);
        }
      }
      ++neighbour;
    }
    _groups.push_back(new Group(_groups.size(),
                                _board, _mark, &_rmap, r.second));
    r.first = _groups[_groups.size() - 1];
  } else {
    _rmap[f] = -1;
  }
  // remove groups
  assert(r.second.size() == deleted.size());
  for(unsigned int i = 0; i < r.second.size(); i++) {
    int idx = deleted[i];
    for(HexField f = HexBoard::NOT_A_FIELD + 1; f < _board.size(); f++) {
      assert(_rmap[f] != idx);
      if(_rmap[f] > idx)
        _rmap[f]--;
    }
    for(unsigned j = i + 1; j < deleted.size(); j++) {
      if(deleted[j] > idx)
        deleted[j]--;
    }
    _groups.erase(_groups.begin() + idx);
  }
  return r;
}

int Grouping::size() const
{
  return _groups.size();
}

Poi<Group> Grouping::operator [](int n) const
{
  assert(0 <= n && (unsigned)n < _groups.size());
  return _groups[n];
}

Grouping::GroupIndex Grouping::operator ()(HexField f) const
{
  return _rmap[f];
}

Grouping::GroupIndex Grouping::groupIndex(const Group *g) const
{
  assert(g && !g->_fields.empty());
  HexField f = g->_fields[0];
  return (*this)(f);
}

const HexBoard &Grouping::board() const
{
  return _board;
}

HexMark Grouping::mark() const
{
  return _mark;
}

//
// Group
//

Group::Group(Grouping::GroupIndex gi, const HexBoard &b, HexField f,
               Grouping::RMap *rmap)
{
  _mark = b.get(f);
  _edge = false;
  _area = 0;

  expand(gi, b, f, rmap);
}

Group::Group(Grouping::GroupIndex gi, const HexBoard &b, HexMark mark,
               Grouping::RMap *rmap,
               const vector<Poi<Group> > &groups)
{
  _mark = mark;
  _edge = false;
  _area = 0;
  for(unsigned i = 0; i < groups.size(); i++) {
    for(unsigned j = 0; j < (*groups[i])._fields.size(); j++) {
      add(gi, b, (*groups[i])._fields[j], rmap);
    }
  }
}

void Group::add(Grouping::GroupIndex gi, const HexBoard &b,
                 HexField f,
                 Grouping::RMap *rmap)
{
  _fields.push_back(f);
  (*rmap)[f] = gi;
  if(f == HexBoard::TOP_EDGE || f == HexBoard::BOTTOM_EDGE) {
    _edge = true;
    _area += b.xs();
  } else if(f == HexBoard::LEFT_EDGE || f == HexBoard::RIGHT_EDGE) {
    _edge = true;
    _area += b.ys();
  } else {
    _area++;
  }
}

void Group::expand(Grouping::GroupIndex gi, const HexBoard &b,
                    HexField f,
                    Grouping::RMap *rmap)
{
  if((*rmap)[f] == -1 && b.get(f) == _mark) {
    add(gi, b, f, rmap);
    if(_mark != HEX_MARK_EMPTY) {
      HexBoard::Iterator neighbour = b.neighbourBegin(f);
      while(neighbour != b.neighbourEnd()) {
        expand(gi, b, *neighbour, rmap);
        ++neighbour;
      }
    }
  }
}

HexMark Group::mark() const
{
  return _mark;
}

bool Group::edge() const
{
  return _edge;
}

int Group::area() const
{
  return _area;
}

const vector<HexField> &Group::fields() const
{
  return _fields;
}

ostream &operator <<(ostream &os, const Group &g)
{
  vector<HexField> fields = g. _fields;
  sort(fields.begin(), fields.end());
  os << g._mark << "{";
  for(unsigned i = 0; i < fields.size(); i++) {
    if(i)
      os << " ";
    os << fields[i];
  }
  os << "}";
  return os;
}
