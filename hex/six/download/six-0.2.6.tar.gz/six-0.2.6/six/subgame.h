// Yo Emacs, this -*- C++ -*-
#ifndef SUBGAME_H
#define SUBGAME_H

#include "group.h"
#include "carrier.h"

/**
 * A subgame is either a virtual connection or a virtual semi connection.
 * It has two end groups and a carrier.
 * See @ref http://earthlink.net/~vanshel for further description.
 *
 * A subgame can have the following statuses:
 * <ul>
 * <li>waiting: it is not enqueued nor processed
 * <li>enqueued: it is enqueued, in other words scheduled for processing
 * <li>processed: it is processed
 * </ul>
 */
class SubGame
{
public:
  /**
   * Constructs a subgame with ends <code>one</code> and <code>other</code>
   * and carrier <code>c</code>.
   * The semi property can also be set.
   */
  SubGame(Group *one, Group *other, const Carrier &c, bool semi = false);

  /**
   * Constructs a new subgame by concatenating two concatable subgames.
   * If the common group by which the concatenation is done is of
   * HEX_MARK_EMPTY then the result is a semi connection.
   */
  SubGame(const SubGame &g0, const SubGame &g1);

  /**
   * @return true iff this subgame is not enqueued and not processed
   */
  bool waiting() const;

  /**
   * @return true iff this subgame was enqueued
   */
  bool enqueued() const;

  /**
   * Marks this subgame as enqueued.
   */
  void setEnqueued();

  /**
   * @return true iff this subgame was processed
   */
  bool processed() const;

  /**
   * Marks this subgame as processed.
   */
  void setProcessed();

  /**
   * @return true iff this subgame is a semi connection
   */
  bool semi() const;
  
  /**
   * Tests if the two subgames have the same end groups (by address)
   * and carriers (by value).
   */
  bool operator ==(const SubGame &g) const;

  /**
   * Lexicographical comparison of the end groups and carriers.
   */
  bool operator <(const SubGame &g) const;

  /**
   * Tests if this subgame has the same end groups (by address)
   * and its carrier includes the carrier of <code>g</code>.
   */
  bool includes(const SubGame &g) const;

  /**
   * @returns true iff <code>g</code> is one of the end groups or is
   * an group of an empty field that's in the carrier.
   */
  bool has(const Group *g) const;

  /**
   * Tests if it is possible to concatenate <code>g</code>
   * to this subgame. If concatenation is possible it sets
   * <code>x</code>, <code>y</code> to the end groups of
   * the result and <code>middle</code> to the common group of
   * the two subgame.
   *
   * No null pointer checking is performed.
   */
  bool concatable(const SubGame &g,
                  Group **x, Group **y, Group **middle) const;

  /**
   * @return the end group with the lower address.
   */
  Group *x() const;

  /**
   * @return the end group with the higher address.
   */
  Group *y() const;

  /**
   * @return the carrier
   */
  const Carrier &carrier() const;

  /**
   * Prints this subgame.
   */
  friend ostream &operator <<(ostream &os, const SubGame &sg);
private:
  Group *_x;
  Carrier _c;
  Group *_y;
  bool _enqueued;
  bool _processed;
  bool _semi;
};

#endif
