#undef NDEBUG

#include "misc.h"
#include "hexboard.h"

#include <assert.h>
#include <algorithm>

class HexBoardTest
{
public:
  void testTopEdgeNeighbours()
  {
    HexBoard b(5, 7);
    HexField f = HexBoard::TOP_EDGE;
    HexBoard::Iterator cur = b.neighbourBegin(f);
    HexBoard::Iterator end = b.neighbourEnd();
    int i = 0;
    while(cur != end) {
      b.printField(cout, *cur);
      cout << endl;
      assert((*cur) == b.coords2Field(b.xs() - 1 - i, 0));
      ++cur;
      ++i;
    }
    cout << endl;
    assert(i == b.xs());
  }

  void testBottomEdgeNeighbours()
  {
    HexBoard b(5, 7);
    HexField f = HexBoard::BOTTOM_EDGE;
    HexBoard::Iterator cur = b.neighbourBegin(f);
    HexBoard::Iterator end = b.neighbourEnd();
    int i = 0;
    while(cur != end) {
      b.printField(cout, *cur);
      cout << endl;
      assert((*cur) == b.coords2Field(b.xs() - 1 - i, b.ys() - 1));
      ++cur;
      ++i;
    }
    cout << endl;
    assert(i == b.xs());
  }

  void testLeftEdgeNeighbours()
  {
    HexBoard b(5, 7);
    HexField f = HexBoard::LEFT_EDGE;
    HexBoard::Iterator cur = b.neighbourBegin(f);
    HexBoard::Iterator end = b.neighbourEnd();
    int i = 0;
    while(cur != end) {
      b.printField(cout, *cur);
      cout << endl;
      assert((*cur) == b.coords2Field(0, b.ys() - 1 - i));
      ++cur;
      ++i;
    }
    cout << endl;
    assert(i == b.ys());
  }

  void testRightEdgeNeighbours()
  {
    HexBoard b(5, 7);
    HexField f = HexBoard::RIGHT_EDGE;
    HexBoard::Iterator cur = b.neighbourBegin(f);
    HexBoard::Iterator end = b.neighbourEnd();
    int i = 0;
    while(cur != end) {
      b.printField(cout, *cur);
      cout << endl;
      assert((*cur) == b.coords2Field(b.xs() - 1, b.ys() - 1 - i));
      ++cur;
      ++i;
    }
    cout << endl;
    assert(i == b.ys());
  }

  void testFieldInTheMiddleNeighbours()
  {
    HexBoard b(5, 7);
    HexField f = b.coords2Field(2, 3);
    HexBoard::Iterator cur = b.neighbourBegin(f);
    HexBoard::Iterator end = b.neighbourEnd();
    int neighbours[6][2] = { {2, 2}, {3, 2}, {3, 3}, {2, 4}, {1, 4}, {1, 3} };
    int i = 0;
    while(cur != end) {
      b.printField(cout, *cur);
      cout << endl;
      assert((*cur) == b.coords2Field(neighbours[i][0], neighbours[i][1]));
      ++cur;
      ++i;
    }
    cout << endl;
    assert(i == 6);
  }

  void testFieldOnTopNeighbours()
  {
    HexBoard b(5, 7);
    HexField f = b.coords2Field(2, 0);
    HexBoard::Iterator cur = b.neighbourBegin(f);
    HexBoard::Iterator end = b.neighbourEnd();
    int neighbours[6][2] = { {2, -1}, {3, -1}, {3, 0},
                             {2, 1}, {1, 1}, {1, 0} };
    int i = 0;
    while(cur != end) {
      b.printField(cout, *cur);
      cout << endl;
      assert((*cur) == b.coords2Field(neighbours[i][0], neighbours[i][1]));
      ++cur;
      ++i;
    }
    cout << endl;
    assert(i == 6);
  }

  void testFieldOnTopLeftNeighbours()
  {
    HexBoard b(5, 7);
    HexField f = b.coords2Field(0, 0);
    HexBoard::Iterator cur = b.neighbourBegin(f);
    HexBoard::Iterator end = b.neighbourEnd();
    int neighbours[6][2] = { {-1, -1}, {0, -1}, {1, 0},
                             {0, 1}, {-1, 1}, {-1, 0} };
    int i = 0;
    while(cur != end) {
      b.printField(cout, *cur);
      cout << endl;
      assert((*cur) == b.coords2Field(neighbours[i][0], neighbours[i][1]));
      ++cur;
      ++i;
    }
    cout << endl;
    assert(i == 6);
  }

  void testTopNeighbour()
  {
    HexBoard b(5, 7);
    for(int y = 0; y < b.ys(); y++) {
      for(int x = 0; x < b.xs(); x++) {
        HexField f = b.coords2Field(x, y);
        assert(y != 0 || b.topNeighbour(f) == HexBoard::TOP_EDGE);
        assert(y == 0 || b.topNeighbour(f) == b.coords2Field(x, y - 1));
      }
    }
  }

  void testBottomNeighbour()
  {
    HexBoard b(5, 7);
    for(int y = 0; y < b.ys(); y++) {
      for(int x = 0; x < b.xs(); x++) {
        HexField f = b.coords2Field(x, y);
        assert(y != b.ys() - 1 ||
               b.bottomNeighbour(f) == HexBoard::BOTTOM_EDGE);
        assert(y == b.ys() ||
               b.bottomNeighbour(f) == b.coords2Field(x, y + 1));
      }
    }
  }

  void testLeftNeighbour()
  {
    HexBoard b(5, 7);
    for(int y = 0; y < b.ys(); y++) {
      for(int x = 0; x < b.xs(); x++) {
        HexField f = b.coords2Field(x, y);
        assert(x != 0 || b.leftNeighbour(f) == HexBoard::LEFT_EDGE);
        assert(x == 0 || b.leftNeighbour(f) == b.coords2Field(x - 1, y));
      }
    }
  }

  void testRightNeighbour()
  {
    HexBoard b(5, 7);
    for(int y = 0; y < b.ys(); y++) {
      for(int x = 0; x < b.xs(); x++) {
        HexField f = b.coords2Field(x, y);
        assert(x != b.xs() - 1 || b.rightNeighbour(f) == HexBoard::RIGHT_EDGE);
        assert(x == b.xs() - 1 ||
               b.rightNeighbour(f) == b.coords2Field(x + 1, y));
      }
    }
  }

  void testWinner()
  {
    {
      HexBoard b(1, 1);
      assert(b.winner() == HEX_MARK_EMPTY);
      b.set(b.coords2Field(0, 0), HEX_MARK_VERT);
      assert(b.winner() == HEX_MARK_VERT);
      b.set(b.coords2Field(0, 0), HEX_MARK_HORI);
      assert(b.winner() == HEX_MARK_HORI);
    }

    {
      HexBoard b(3, 3);
      assert(b.winner() == HEX_MARK_EMPTY);
      b.set(b.coords2Field(0, 0), HEX_MARK_VERT);
      assert(b.winner() == HEX_MARK_EMPTY);
      b.set(b.coords2Field(2, 1), HEX_MARK_VERT);
      assert(b.winner() == HEX_MARK_EMPTY);
      b.set(b.coords2Field(0, 1), HEX_MARK_VERT);
      assert(b.winner() == HEX_MARK_EMPTY);
      b.set(b.coords2Field(1, 1), HEX_MARK_VERT);
      assert(b.winner() == HEX_MARK_EMPTY);
      b.set(b.coords2Field(2, 2), HEX_MARK_VERT);
      assert(b.winner() == HEX_MARK_VERT);
    }
  }

};

int main()
{
  HexBoardTest t;
  t.testTopEdgeNeighbours();
  t.testBottomEdgeNeighbours();
  t.testLeftEdgeNeighbours();
  t.testRightEdgeNeighbours();
  t.testFieldInTheMiddleNeighbours();
  t.testFieldOnTopNeighbours();
  t.testFieldOnTopLeftNeighbours();

  t.testTopNeighbour();
  t.testBottomNeighbour();
  t.testLeftNeighbour();
  t.testRightNeighbour();

  t.testWinner();
  return 0;
}
