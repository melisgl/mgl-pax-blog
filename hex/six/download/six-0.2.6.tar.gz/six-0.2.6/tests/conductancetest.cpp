#include "conductance.h"
#include "misc.h"

#include "testutil.h"

#include <math.h>

bool operator <(const pair<HexMove, pair<double, double> > &m1,
                const pair<HexMove, pair<double, double> > &m2)
{
  // m1 < m2 iff m1.second > m2.second
  return m1.second.first + m1.second.second >
    m2.second.first + m2.second.second;
}

class ConductanceTest
{
public:

  void showCond(const HexBoard &b)
  {
    cout << b;
    Connector vert;
    Connector hori;
    vert.init(b, HEX_MARK_VERT);
    hori.init(b, HEX_MARK_HORI);
    Conductance vertCond(vert);
    Conductance horiCond(hori);
    cout << "Vert resistance: " << vertCond.resistance() << endl;
    cout << "Hori resistance: " << horiCond.resistance() << endl;
    cout << "Vb=" << log(horiCond.resistance() / vertCond.resistance())
         << endl;

    vector<pair<HexMove, pair<double, double> > > moves;
    {
      const Grouping &bg = vert.grouping();
      const Grouping &wg = hori.grouping();
      for(HexField f = HexBoard::FIRST_NORMAL_FIELD; f < b.size(); f++) {
        if(b.get(f) == HEX_MARK_EMPTY) {
            HexMove m(HEX_MARK_VERT, f);
            double be = vertCond.energy(bg(f));
            double we = horiCond.energy(wg(f));
            moves.push_back(pair<HexMove, pair<double, double> >
                            (m, pair<double, double>(be, we)));
        }
      }
    }

    sort(moves.begin(), moves.end());
    for(unsigned i = 0; i < moves.size(); i++) {
      b.printField(cout, moves[i].first.field());
      cout << " V=" << moves[i].second.first + moves[i].second.second
           << " Eb=" << moves[i].second.first
           << " Ew=" << moves[i].second.second
           << endl;
    }
  }

  void testConductance()
  {
    {
      HexBoard b(1, 1);
      showCond(b);
    }

    {
      HexBoard b(2, 2);
      showCond(b);
    }

    {
      HexBoard b(3, 3);
      showCond(b);
    }

    {
      HexBoard b(4, 4);
      showCond(b);
    }

    {
      HexBoard b(7, 7);
      showCond(b);
    }

    {
      HexBoard b(7, 7);
      b.set(b.coords2Field(3, 3), HEX_MARK_VERT);
      showCond(b);
    }
    {
      HexBoard b(7, 7);
      b.set(b.coords2Field(2, 3), HEX_MARK_VERT);
      showCond(b);
    }

    {
      HexBoard b(11, 11);
      showCond(b);
    }

//     {
//       HexBoard b(11, 11);
//       b.play(HexMove(HEX_MARK_VERT, 5, 5));
//       showCond(b);
//     }
//     {
//       HexBoard b(11, 11);
//       b.play(HexMove(HEX_MARK_VERT, 4, 7));
//       showCond(b);
//     }
//     {
//       HexBoard b(11, 11);
//       b.play(HexMove(HEX_MARK_VERT, 3, 6));
//       showCond(b);
//     }

//     {
//       Connector vert;
//       Connector hori;
//       {
//         HexBoard b(11, 11);
//         vert.init(b, HEX_MARK_VERT);
//         hori.init(b, HEX_MARK_HORI);
//         vector<HexMove> m = parseMoves("j11 c9 f5 b7 h4 i4 i3 k2 j3 k3 k1 j2
//                                      j1 i2 j4 k4 j5 k5 j6 k6 j7 e5 d7 c8 c6
//                                      c7 d6 b6 c4 c5 d4 a5 b3 a4 a3 k7 j8 k8
//                                      i10 c3 b4 j10 i11 k10 k11 g4 d5
//                                      g5 e8 e7 d8 f8 f7 i9 j9 h6 g7
//                                      h9 h8");
//         for(unsigned i = 0; i < m.size(); i++) {
//           vert.move(m[i]);
//           hori.move(m[i]);
//         }
//       }
//       Conductance vertCond(vert, 1);
//       Conductance horiCond(hori);
//       cout << "Vert resistance: " << vertCond.resistance() << endl;
//       cout << "Hori resistance: " << horiCond.resistance() << endl;
// //       const HexBoard &b = vert.grouping().board();
// //       vector<pair<HexMove, double> > moves;
// //       {
// //         const Grouping &bg = vert.grouping();
// //         const Grouping &wg = hori.grouping();
// //         int x, y;
// //         for(y = 0; y < b.ys(); y++) {
// //           for(x = 0; x < b.xs(); x++) {
// //             if(b.get(x, y) == HEX_MARK_EMPTY) {
// //               HexMove m(b.next(), x, y);
// //               double be = vertCond.energy(bg(bg.field(x, y)));
// //               double we = horiCond.energy(wg(wg.field(x, y)));
// //               moves.push_back(pair<HexMove, double>(m, be));
// //             }
// //           }
// //         }
// //       }

// //       sort(moves.begin(), moves.end());
// //       for(unsigned i = 0; i < moves.size(); i++) {
// //         cout << moves[i].first << " V=" << moves[i].second << endl;
// //         vert.move(moves[i].first);
// //         hori.move(moves[i].first);
// //         Conductance vertCond2(vert);
// //         Conductance horiCond2(hori);
// //         cout << "Vert resistance: " << vertCond2.resistance() << endl;
// //         cout << "Hori resistance: " << horiCond2.resistance() << endl;
// //       }
//     }
  }
};

int main()
{
  {
    ConductanceTest t;
    t.testConductance();
  }
  return 0;
}
