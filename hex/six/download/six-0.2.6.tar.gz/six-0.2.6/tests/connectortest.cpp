#undef NDEBUG

#include "connector.h"
#include "hexgame.h"
#include "misc.h"

#include "testutil.h"

#include <assert.h>
#include <math.h>

class ConnectorTest
{
public:
  static void printNew(const Connector::SubGameQueue &newConns)
  {
    cout << "New connections:" << endl;
    for(unsigned int i = 0; i < newConns.size(); i++) {
      if(!(*newConns[i]).processed()) {
        cout << *newConns[i] << endl;
      }
    }
    cout << endl;
  }

  static void printSemis(const Connector::SemiBatchMap &semis)
  {
    cout << "Semi connections:" << endl;
    Connector::SemiBatchMap::const_iterator cur = semis.begin();
    Connector::SemiBatchMap::const_iterator end = semis.end();
    while(cur != end) {
      Connector::SemiBatch::const_iterator setcur = (*cur).second.begin();
      Connector::SemiBatch::const_iterator setend = (*cur).second.end();
      while(setcur != setend) {
        cout << **setcur << endl;
        ++setcur;
      }
      ++cur;
    }
    cout << endl;
  }

  static int countSemis(const Connector::SemiBatchMap &semis)
  {
    int r = 0;
    Connector::SemiBatchMap::const_iterator cur = semis.begin();
    Connector::SemiBatchMap::const_iterator end = semis.end();
    while(cur != end) {
      Connector::SemiBatch::const_iterator setcur = (*cur).second.begin();
      Connector::SemiBatch::const_iterator setend = (*cur).second.end();
      while(setcur != setend) {
        r++;
        ++setcur;
      }
      ++cur;
    }
    return r;
  }

  static void printConns(const Connector::ConnBatchMap &conns)
  {
    cout << "Conns:" << endl;
    Connector::ConnBatchMap::const_iterator cur = conns.begin();
    Connector::ConnBatchMap::const_iterator end = conns.end();
    while(cur != end) {
      //cout << "R=" << (*cur).first.resistance() << " (";
      Connector::ConnBatch::const_iterator setcur = (*cur).second.begin();
      Connector::ConnBatch::const_iterator setend = (*cur).second.end();
      while(setcur != setend) {
        //cout << " " << **setcur;
        cout << **setcur << endl;
        ++setcur;
      }
      //cout << " )" << endl;
      ++cur;
    }
  }

  static int countConns(const Connector::ConnBatchMap &conns)
  {
    int r = 0;
    Connector::ConnBatchMap::const_iterator cur = conns.begin();
    Connector::ConnBatchMap::const_iterator end = conns.end();
    while(cur != end) {
      Connector::ConnBatch::const_iterator setcur = (*cur).second.begin();
      Connector::ConnBatch::const_iterator setend = (*cur).second.end();
      while(setcur != setend) {
        r++;
        ++setcur;
      }
      ++cur;
    }
    return r;
  }

  static void print(const Grouping &gi)
  {
    int i;
    for(i = 0; i < gi.size(); i++) {
      const Group &g = *gi[i];
      cout << g;
      cout << endl;
    }
  }

  static void print(const Connector &c, bool dump = 0)
  {
//     print(c._groups);
    cout << "potentialWinner=" << c.potentialWinner() << endl;
    cout << "nNew=" << c._subgameQueue.size()
         << ", nSemi=" << countSemis(c.semis())
         << ", nConn=" << countConns(c.conns()) << endl;
    if(dump) {
      printNew(c._subgameQueue);
      printSemis(c.semis());
      printConns(c.conns());
    }
  }

  static void checkNoEmptySemiBatch(const Connector::SemiBatchMap &semis)
  {
    Connector::SemiBatchMap::const_iterator cur = semis.begin();
    Connector::SemiBatchMap::const_iterator end = semis.end();
    while(cur != end) {
      if((*cur).second.empty()) {
        cout << *(*cur).first.start() << " " << *(*cur).first.end() << endl;
      }
      assert(!(*cur).second.empty());
      ++cur;
    }
  }

  static void checkNoEmptyConnBatch(const Connector::ConnBatchMap &conns)
  {
    Connector::ConnBatchMap::const_iterator cur = conns.begin();
    Connector::ConnBatchMap::const_iterator end = conns.end();
    while(cur != end) {
      if((*cur).second.empty()) {
        cout << *(*cur).first.start() << " " << *(*cur).first.end() << endl;
      }
      assert(!(*cur).second.empty());
      ++cur;
    }
  }

  static void checkSemiBatchOrdering(const Connector::SemiBatchMap &semis)
  {
    Connector::SemiBatchMap::const_iterator cur = semis.begin();
    Connector::SemiBatchMap::const_iterator end = semis.end();
    while(cur != end) {
      Connector::SemiBatch::const_iterator scur = (*cur).second.begin();
      Connector::SemiBatch::const_iterator send = (*cur).second.end();
      int size = 0;
      while(scur != send) {
        assert(size <= (**scur).carrier().size());
        size = (**scur).carrier().size();
        ++scur;
      }
      ++cur;
    }
  }

  static void checkConnBatchOrdering(const Connector::ConnBatchMap &conns)
  {
    Connector::ConnBatchMap::const_iterator cur = conns.begin();
    Connector::ConnBatchMap::const_iterator end = conns.end();
    while(cur != end) {
      Connector::ConnBatch::const_iterator scur = (*cur).second.begin();
      Connector::ConnBatch::const_iterator send = (*cur).second.end();
      int size = 0;
      while(scur != send) {
        assert(size <= (**scur).carrier().size());
        size = (**scur).carrier().size();
        ++scur;
      }
      ++cur;
    }
  }

  void check(const Connector &c)
  {
    checkNoEmptyConnBatch(c.conns());
    checkNoEmptySemiBatch(c.semis());
    checkConnBatchOrdering(c.conns());
    checkSemiBatchOrdering(c.semis());
  }

  void testSsss()
  {
    {
      HexBoard b(1, 1);
      cout << b;
      Connector vert;
      Connector hori;
      vert.init(b, HEX_MARK_VERT);
      hori.init(b, HEX_MARK_HORI);
      assert(countConns(vert.conns()) == 2);
      assert(countSemis(vert.semis()) == 1);
      assert(countConns(hori.conns()) == 2);
      assert(countSemis(hori.semis()) == 1);
    }

    {
      HexBoard b(1, 2);
      cout << b;
      Connector vert;
      Connector hori;
      vert.init(b, HEX_MARK_VERT);
      print(vert, true);
      hori.init(b, HEX_MARK_HORI);
      assert(vert.winner() == b.winner() &&
             hori.winner() == b.winner());
      assert(vert.potentialWinner() == HEX_MARK_EMPTY);
      assert(countConns(vert.conns()) == 3);
      assert(countSemis(vert.semis()) == 2);
      assert(hori.potentialWinner() == HEX_MARK_HORI);
    }

    {
      HexBoard b(2, 1);
      cout << b;
      Connector vert;
      Connector hori;
      vert.init(b, HEX_MARK_VERT);
      hori.init(b, HEX_MARK_HORI);
      assert(vert.winner() == b.winner() &&
             hori.winner() == b.winner());
      assert(vert.potentialWinner() == HEX_MARK_VERT);
      assert(hori.potentialWinner() == HEX_MARK_EMPTY);
      assert(countConns(hori.conns()) == 3);
      assert(countSemis(hori.semis()) == 2);
    }

    {
      HexBoard b(2, 2);
      cout << b;
      Connector vert;
      Connector hori;
      vert.init(b, HEX_MARK_VERT);
      hori.init(b, HEX_MARK_HORI);
      print(vert, 1);
      assert(vert.winner() == b.winner() &&
             hori.winner() == b.winner());
      assert(vert.potentialWinner() == HEX_MARK_EMPTY);
      assert(countConns(vert.conns()) == 12);
      assert(countSemis(vert.semis()) == 10);
      assert(hori.potentialWinner() == HEX_MARK_EMPTY);
      assert(countConns(hori.conns()) == 12);
      assert(countSemis(hori.semis()) == 10);
    }

    {
      HexBoard b(2, 3);
      cout << b;
      Connector vert;
      Connector hori;
      vert.init(b, HEX_MARK_VERT);
      hori.init(b, HEX_MARK_HORI);
      assert(vert.winner() == b.winner() &&
             hori.winner() == b.winner());
      assert(vert.potentialWinner() == HEX_MARK_EMPTY);
      assert(countConns(vert.conns()) == 18);
      assert(hori.potentialWinner() == HEX_MARK_HORI);
    }
  }

  void testCccc()
  {
    HexBoard b(5, 5);
    cout << b;
    Connector vert(-1, -1, 20, -1, 5);
    Connector hori;
    vert.init(b, HEX_MARK_VERT);
    print(vert, 1);
    vert.move(HexMove(HEX_MARK_VERT, b.coords2Field(0, 1)));
    print(vert, 1);
    hori.init(b, HEX_MARK_HORI);
    print(hori, 1);
  }

  void testWins()
  {
    {
      HexBoard b0(3, 3);
      for(HexField f = HexBoard::FIRST_NORMAL_FIELD; f < b0.size(); f++) {
        HexBoard b(b0);
        b.set(f, HEX_MARK_VERT);
        cout << b;
        Connector vert;
        Connector hori;
        vert.init(b, HEX_MARK_VERT);
        int x, y;
        b.field2Coords(f, &x, &y);
        assert((y + x == 2 || (x == 0 && y == 1) || (x == 2 && y == 1)) ==
               (vert.potentialWinner() == HEX_MARK_VERT));
        hori.init(b, HEX_MARK_HORI);
        assert(hori.potentialWinner() == HEX_MARK_EMPTY);
      }
    }
  }

  HexMove randomMove(const HexGame &g)
  {
    vector<HexMove> moves;
    for(HexField f = HexBoard::FIRST_NORMAL_FIELD; f < g.board().size(); f++) {
      if(g.board().get(f) == HEX_MARK_EMPTY) {
        moves.push_back(HexMove(g.next(), f));
      }
    }
    return moves[RANDOM(moves.size())];
  }

  void testMove(const HexBoard &b0, const vector<HexMove> &moves,
                int softMaxConn = -1, int hardMaxConn = -1,
                int softMaxSemi = -1, int hardMaxSemi = -1,
                int maxInOrRule = 5, bool useEdge = false)
  {
    HexGame g(b0);
    cout << g.board();
    Connector vert(softMaxConn, hardMaxConn, softMaxSemi, hardMaxSemi,
                    maxInOrRule, useEdge);
    Connector hori(softMaxConn, hardMaxConn, softMaxSemi, hardMaxSemi,
                    maxInOrRule, useEdge);
    check(vert);
    check(hori);
    cout << "Initializing ..." << endl;
    vert.init(g.board(), HEX_MARK_VERT);
    hori.init(g.board(), HEX_MARK_HORI);
    check(vert);
    check(hori);
    for(unsigned i = 0; i < moves.size(); i++) {
      HexMove m = moves[i];
      cout << "Playing ";
      g.printMove(cout, m);
      cout << endl;
      g.play(m);
      cout << g.board();
      vert.move(m);
      Connector vert0(softMaxConn, hardMaxConn,
                       softMaxSemi, hardMaxSemi, maxInOrRule);
      vert0.init(g.board(), HEX_MARK_VERT);
      print(vert);
      print(vert0);
      if(vert.winner() == HEX_MARK_EMPTY &&
         vert.potentialWinner() == HEX_MARK_VERT) {
        cout << "WC=" << vert.winningCarrier() << endl;
      }
      check(vert0);
      check(vert);
      assert(vert.winner() == vert0.winner());
      assert(vert.potentialWinner() == vert0.potentialWinner());
//       if(softMaxConn == -1 && hardMaxConn == -1 &&
//          softMaxSemi == -1 && hardMaxSemi == -1) {
//         assert(vert.potentialWinner() != HEX_MARK_EMPTY ||
//                (countConns(vert.conns()) == countConns(vert0.conns()) &&
//                 countSemis(vert.semis()) == countSemis(vert0.semis())));
//       }
      hori.move(m);
      Connector hori0(softMaxConn, hardMaxConn,
                       softMaxSemi, hardMaxSemi, maxInOrRule);
      hori0.init(g.board(), HEX_MARK_HORI);
      print(hori);
      print(hori0);
      if(hori.winner() == HEX_MARK_EMPTY &&
         hori.potentialWinner() == HEX_MARK_HORI) {
        cout << "WC=" << hori.winningCarrier() << endl;
      }
      check(hori0);
      check(hori);
      assert(hori.winner() == hori0.winner());
      assert(hori.potentialWinner() == hori0.potentialWinner());
//       if(softMaxConn == -1 && hardMaxConn == -1 &&
//          softMaxSemi == -1 && hardMaxSemi == -1) {
//         assert(hori.potentialWinner() != HEX_MARK_EMPTY ||
//                (countConns(hori.conns()) == countConns(hori0.conns()) &&
//                 countSemis(hori.semis()) == countSemis(hori0.semis())));
//       }
    }
  }

  void testMove()
  {
    {
      HexBoard b(2, 2);
      testMove(b, parseMoves(b, "a1"), 20, 20, 20, 20, 5);
    }

    {
      HexBoard b(11, 11);
      testMove(b, parseMoves(b, "f3 SWAP f6"), -1, -1, 7, -1, 4, true);
    }

    {
      HexBoard b(11, 11);
      testMove(b, parseMoves(b, "b1 c9 f6 e6 d8 c8 d7 c7 d6 c6 d3 c3
                           c4 b4 b5 a5 a6 d4 e3 i4 h7 g7 h5 i5
                           h6 j6 i8 j9 k7 h8 i7 f4 e4 e8 e7 j5
                           j7 g2 e5 e10 g6"),
               -1, -1, 5, -1, 4);
    }

    {
      HexBoard b(11, 11);
      testMove(b, parseMoves(b, "B1 F6 H3 E4 F1 G1 F7 E7 E9 D9 C11 B10
                           C9 C10 A11 B11 D8 E8 F3 E3 F2 D2 D1 E1
                           E6 G4 G3 F4 F5 G5 D3 E2"),
               -1, -1, 5, -1, 4);
    }

    {
      HexBoard b(11, 11);
      testMove(b, parseMoves(b, "B1 F6 F5 G5 H3 G3 G4 D6 E4 B5 J2 C3 C4 B4 C6 D5 D3 E3 D4 C5 D7 E6 D1 D2 F7 G8 H6 E7 D11 F10 E8 D8 E1 E2 F1 G2 H1 G1 F3 F2 C10 D9 E9 D10 B10 C11"),
              -1, -1, 7, -1, 4);
    }

    {
      HexBoard b(11, 11);
      testMove(b, parseMoves(b, "I3 F6 F5 C6 C9 D7 D3 E4 F3 E3 D6 C7 D5 H4 H2 F4 G3 G4 G5 K3 J5 H6 H5 I5 H7 F8 D10 F9 E11 G10 G9 F10 G7 G6 I4 B5 C5 B6 C3 A3 A4 B3 B4 D4 C4 E5 E6 K4 K2 J3 J2"),
               20, 20, 20, 20, 5);
    }

    {
      HexBoard b(11, 11);
      testMove(b, parseMoves(b, "I3 F5 F6 G3 G4 F4 D7 G5 G7 J6 H7 K4 I8 K9 K7 J8 J7 I7 H8 G6 F7 A8 C7 B8 B6 C6 B7 A6 A7 E1 E7"),
               20, 20, 20, 20, 5);
    }

    {
      HexBoard b(11, 11);
      testMove(b, parseMoves(b, "C8 F6 F5 H4 H3 J2 J1 I2 I3 J3 I4 J4 I6 E8 H5 D6 E7 E6 F7 H6 G8 J7 H7 J6 J5 A8 B9 A10 A9 G7 F8 D8 D7"),
               20, 20, 20, 20, 5);
    }

    {
      HexBoard b(11, 11);
      testMove(b, parseMoves(b, "J11 C9 F5 B7 H4 I4 I3 K2 J3 K3 K1 J2 J1 I2 J4 K4 J5 K5 J6 K6 J7 E5 D7 C8 C6 C7 D6 B6 C4 C5 D4 A5 B3 A3 A4 C3 B4 F3 D5 E6 E7 F6 F7 G6 G7 H6 H7 I7 I6 K7 J8 I10 K8"),
               20, 20, 20, 20, 5);
    }
  }

  void testRandomMoves() {
    for(int i = 0; i < 1000; i++) {
      HexGame g(HexBoard(4, 4));
      vector<HexMove> m;
      while(g.board().winner() == HEX_MARK_EMPTY) {
        HexMove move = randomMove(g);
        m.push_back(move);
        g.play(move);
      }
      testMove(HexBoard(4, 4), m, -1, -1, -1, -1, 5);
    }
  }

  void testPerf()
  {
    {
      HexBoard b(11, 11);
      Connector c(-1, -1, 10, -1, 4, 0);
      vector<HexMove> m;
      m = parseMoves(b, "J11 C9 F5 B7 H4 I4 I3 K2 J3 K3 K1 J2 J1 I2 J4 K4 J5 K5 J6 K6 J7 E5 D7 C8 C6 C7 D6 B6 C4 C5 D4 A5 B3 A3 A4 C3 B4 F3 D5 E6 E7 F6 F7 G6 G7 H6 H7 I7 I6 K7 J8 I10 K8");
//       m = parseMoves("B1 F6 H3 E4 F1 G1 F7 E7 E9 D9 C11 B10
//                      C9 C10 A11 B11 D8 E8 F3 E3 F2 D2 D1 E1
//                      E6 G4 G3 F4 F5 G5 D3 E2");

      clock_t t0, t1;
      clock_t ts0, ts1;
      clock_t tm0, tm1;
      vector<pair<clock_t, clock_t> > tmi(m.size());
      t0 = ts0 = clock();
      c.init(b, HEX_MARK_HORI);
      ts1 = tm0 = clock();
      for(unsigned i = 0; i < m.size(); i++) {
        tmi[i].first = clock();
        c.move(m[i]);
        tmi[i].second = clock();
        cout << "i=" << i << m[i].mark();
        b.printField(cout, m[i].field());
        cout << endl;
        cout << c.grouping().board();
      }
      tm1 = t1 = clock();
      cout << "Setup time: " << ((long)ts1 - (long)ts0) << endl;
      for(unsigned i = 0; i < tmi.size(); i++) {
        cout << "Move[" << i << "] time: "
             << ((long)tmi[i].second - (long)tmi[i].first) << endl;
      }
      cout << "Move time: " << ((long)tm1 - (long)tm0) << endl;
      cout << "Total time: " << ((long)t1 - (long)t0) << endl;
    }
    {
      HexBoard b(11, 11);
      //     b.play(HexMove(HEX_MARK_VERT, 0, 0));
      Connector c(-1, -1, 10, -1, 4, false);
      vector<HexMove> m;
      m = parseMoves(b, "J11 C9 F5 B7 H4 I4 I3 K2 J3 K3 K1 J2 J1 I2 J4 K4 J5 K5 J6 K6 J7 E5 D7 C8 C6 C7 D6 B6 C4 C5 D4 A5 B3 A3 A4 C3 B4 F3 D5 E6 E7 F6 F7 G6 G7 H6 H7 I7 I6 K7 J8 I10 K8");
//       m = parseMoves("B1 F6 H3 E4 F1 G1 F7 E7 E9 D9 C11 B10
//                      C9 C10 A11 B11 D8 E8 F3 E3 F2 D2 D1 E1
//                      E6 G4 G3 F4 F5 G5 D3 E2");

      clock_t t0, t1;
      clock_t ts0, ts1;
      clock_t tm0, tm1;
      vector<pair<clock_t, clock_t> > tmi(m.size());
      t0 = ts0 = clock();
      c.init(b, HEX_MARK_VERT);
      ts1 = tm0 = clock();
      for(unsigned i = 0; i < m.size(); i++) {
        tmi[i].first = clock();
        c.move(m[i]);
        tmi[i].second = clock();
        cout << "i=" << i << m[i].mark();
        b.printField(cout, m[i].field());
        cout << endl;
        cout << c.grouping().board();
      }
      tm1 = t1 = clock();
      cout << "Setup time: " << ((long)ts1 - (long)ts0) << endl;
      for(unsigned i = 0; i < tmi.size(); i++) {
        cout << "Move[" << i << "] time: "
             << ((long)tmi[i].second - (long)tmi[i].first) << endl;
      }
      cout << "Move time: " << ((long)tm1 - (long)tm0) << endl;
      cout << "Total time: " << ((long)t1 - (long)t0) << endl;
    }
  }

};

int main()
{
  ConnectorTest t;
//   t.testCccc();
//   t.testSsss();
//   t.testWins();
//   t.testMove();
//   t.testRandomMoves();
  t.testPerf();
  return 0;
}
