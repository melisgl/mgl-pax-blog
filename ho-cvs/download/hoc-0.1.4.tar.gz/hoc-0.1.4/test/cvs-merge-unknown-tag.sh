#!/bin/sh
# with local repository it works, but fails with pserver and ext?
# or was this bug fixed since 1.11.1p1?
set -e

rm -rf cvs-merge-unknown-tag
mkdir cvs-merge-unknown-tag
cd cvs-merge-unknown-tag
export CVSROOT=$PWD/cvsroot/
cvs init

export CVSROOT=:ext:$USER@localhost:$PWD/cvsroot/
export CVS_RSH=ssh

BASE=$PWD
mkdir M
cd M
cvs import -m "Created module M" M no-vendor init
cd $BASE
rmdir M

cd $BASE
cvs -f co M
cd M
echo 1 > x
cvs add x
cvs ci -m "added x"
cvs tag -b "tag-in-M"

cd $BASE
mkdir N
cd N
cvs import -m "Created module N" N no-vendor init
cd $BASE
rmdir N

cd $BASE
cvs -f co N
cd N
echo 1 > x
cvs add x
cvs ci -m "added x"
cvs tag -b 'xxx'

cd $BASE
cvs co -d N2 N
cd N2
echo 2 >> x
cvs ci -m "modified x"

cd $BASE/N
cvs up -j "tag-in-M" || exit 0
exit 1
