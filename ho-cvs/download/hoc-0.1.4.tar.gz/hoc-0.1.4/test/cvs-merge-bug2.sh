#!/bin/sh
# same as cvs-merge-bug but with a branch instead of MAIN
set -e

rm -rf cvs-merge-bug2
mkdir cvs-merge-bug2
cd cvs-merge-bug2
export CVSROOT=$PWD/cvsroot/
cvs init

BASE=$PWD
mkdir M
cd M
cvs import -m "Created module M" M no-vendor init

cd $BASE
cvs co -d M1 M
cd M1
echo > dummy
cvs add dummy
cvs ci -m "created necessary file for tag to work"

cvs tag -b BBB
cvs up -r BBB
echo 1 > x
cvs add x
cvs ci -m "added x"

echo "let's create a branch and modify x on it"
cd $BASE
cvs co -d M2 -r BBB M
cd M2
cvs tag -b BRANCH
cvs up -r BRANCH
echo 2 >> x
cvs ci -m "modified x on BRANCH"

echo "Commit a new revision to BBB so that"
echo "M1 does not have the latest version"
cvs up -r BBB
echo 3 >> x
cvs ci -m "modified x on BBB"

echo "now that everything is set up let's merge"
cd $BASE/M1
cat CVS/Entries  # here x is at revision 1.1
cvs up -j BRANCH
cat CVS/Entries  # here x is at revision 1.2
cat x            # and the conflict of course

cvs status x | grep 'Working revision:    1.1.2.1 '
