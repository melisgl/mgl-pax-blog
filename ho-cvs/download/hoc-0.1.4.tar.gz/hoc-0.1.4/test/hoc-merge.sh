#!/bin/sh
# because cvs up -j updates to the end of the branch _and_ merges,
# it is tricky to keep the VERSION file right
set -e

rm -rf hoc-merge
mkdir hoc-merge
cd hoc-merge
export CVSROOT=$PWD/cvsroot/
cvs init

BASE=$PWD
mkdir M
cd M
hoc create -m "Created module M" M init

cd $BASE
hoc co -d M1 M
cd M1
echo 1 > x
hoc add x
echo 1 > y
hoc add y
hoc ci --patch -m "added x and y"
hoc --meta status

echo "let's create a branch and modify x on it"
cd $BASE
hoc co -d M2 M
cd M2
hoc branch BRANCH
hoc up -r BRANCH
echo 2 >> x
touch a
hoc add a
hoc ci --patch -m "modified x on BRANCH"

echo "Commit a new revision to MAIN so that"
echo "M1 does not have the latest version"
hoc sw
echo 3 >> x
echo 3 >> y
echo 3 >> z
hoc add z
hoc ci --patch -m "modified x and y on MAIN"

echo "now that everything is set up let's merge"
cd $BASE/M1
hoc --debug up -j BRANCH
cd HOC
cvs status VERSION | grep 'Needs Patch'
cvs status MAP | grep 'Needs Merge'
grep '#v0.0.1' VERSION || exit 1
