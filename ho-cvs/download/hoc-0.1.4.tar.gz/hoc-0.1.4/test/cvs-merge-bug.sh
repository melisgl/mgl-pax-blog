#!/bin/sh
set -e

rm -rf cvs-merge-bug
mkdir cvs-merge-bug
cd cvs-merge-bug
export CVSROOT=$PWD/cvsroot/
cvs init

BASE=$PWD
mkdir M
cd M
cvs import -m "Created module M" M no-vendor init

cd $BASE
cvs co -d M1 M
cd M1
echo 1 > x
cvs add x
echo 1 > y
cvs add y
cvs ci -m "added x and y"
cvs tag baseline

echo "let's create a branch and modify x on it"
cd $BASE
cvs co -d M2 M
cd M2
cvs tag -b BRANCH
cvs up -r BRANCH
echo 2 >> x
cvs rm -f y
echo 2 >> z
cvs add z
cvs ci -m "modified x, removed y and added z on BRANCH"

echo "Commit a new revision to MAIN so that"
echo "M1 does not have the latest version"
cvs up -A
echo 3 >> x
#echo 3 >> z
#cvs add z
cvs ci -m "modified x and added z on MAIN"

echo "now that everything is set up let's merge"
cd $BASE/M1
cvs up -rbaseline
cvs -t up -j BRANCH

cvs status
cvs status x | grep 'Working revision:' | grep '1.1'
