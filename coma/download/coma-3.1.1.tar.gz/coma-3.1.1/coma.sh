#!/bin/sh
BASE=`dirname $0`
make -C $BASE
$BASE/src/coma.sh "$@"
