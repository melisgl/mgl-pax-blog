#!/bin/sh -e

cd `dirname $0`
BASE=$PWD

echo Setting up cvs
export CVSROOT=$BASE/cvsroot
export EDITOR=$BASE/null-editor.sh
rm -rf $CVSROOT
cvs init

echo Creating dirs
cd $BASE
rm -rf work
mkdir -p work/create

echo create simple-cvs-item module
cp -r $BASE/rep/simple-cvs-item $BASE/work/create
cd $BASE/work/create/simple-cvs-item/cm/
$BASE/../coma.sh install --with cvs-item --without hoc-item
cd ..
cvs import -m "SD" simple-cvs-item init rel1

echo create simple-item module
cp -r $BASE/rep/simple-item $BASE/work/create
cd $BASE/work/create/simple-item/cm/
$BASE/../coma.sh g
cd ..
hoc create -m "SD" simple-item init

echo create complex-item module
cp -r $BASE/rep/complex-item $BASE/work/create
cd $BASE/work/create/complex-item/cm/
$BASE/../coma.sh g
cd ..
hoc create -m "SD" complex-item init

echo create kit module
cp -r $BASE/rep/test-kit $BASE/work/create
cd $BASE/work/create/test-kit/cm/
$BASE/../coma.sh install --with hoc-kit-item --with cvs-kit-item
cd ..
hoc create -m "sd" test-kit init

echo CHECK OUT TEST-KIT
cd $BASE/work
hoc co test-kit
cd test-kit
cm/coma.sh

echo MODIFYING SIMPLE-ITEM
cd $BASE/work/test-kit/simple-item
echo "NEW LINE" >> out.coma
hoc ci -m "Modify" --patch

echo MODIFYING SIMPLE-ITEM2
cd $BASE/work/test-kit/subdir/simple-item2
echo "NEW LINE" >> out.coma
hoc branch dev
hoc sw dev
hoc ci -m "Modify 2" --patch

echo committing kit
cd $BASE/work/test-kit
hoc ci -m "Mod" --patch

echo RUNNING hoc up -r '#v0.0.0'
hoc up -r '#v0.0.0'

echo RUNNING hoc fw
hoc fw
