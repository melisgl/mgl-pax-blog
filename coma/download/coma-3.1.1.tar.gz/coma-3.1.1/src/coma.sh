#!/bin/sh
COMADIR=`dirname $0`

# executables
COMA_CLISP=${COMA_CLISP:-clisp}
COMA_CMUCL=${COMA_CMUCL:-lisp}
COMA_SBCL=${COMA_SBCL:-sbcl}

# options
COMA_CLISP_OPTIONS="-q -ansi -norc"
COMA_CLISP_LOAD_OPTIONS=""

COMA_CMUCL_OPTIONS="-quiet -noinit"
COMA_CMUCL_LOAD_OPTIONS="-load"

COMA_SBCL_OPTIONS="--noinform --noprint --userinit /dev/null --sysinit /dev/null"
COMA_SBCL_LOAD_OPTIONS="--load"

# Enable interactive debug when COMA_DEBUG is set.
if [ "$COMA_DEBUG" ]; then
    COMA_CLISP_OPTIONS="$COMA_CLISP_OPTIONS -interactive-debug"
else
    COMA_CMUCL_OPTIONS="$COMA_CMUCL_OPTIONS -batch"
    COMA_SBCL_OPTIONS="$COMA_SBCL_OPTIONS --disable-debugger"
fi

# run coma
case $COMA_LISP in
    ""|clisp)
        $COMA_CLISP $COMA_CLISP_OPTIONS \
            $COMA_CLISP_LOAD_OPTIONS "$COMADIR/coma.lisp" "$@"
        ;;
    cmucl)
        $COMA_CMUCL $COMA_CMUCL_OPTIONS \
            $COMA_CMUCL_LOAD_OPTIONS "$COMADIR/coma.lisp" "$@"
        ;;
    sbcl)
        $COMA_SBCL $COMA_SBCL_OPTIONS \
            $COMA_SBCL_LOAD_OPTIONS "$COMADIR/coma.lisp" "$@"
        ;;
    *)
        echo "Unsupported value for COMA_LISP: $COMA_LISP." >&2
        echo "Valid values: clisp, cmucl and sbcl." >&2
        exit 1
        ;;
esac
